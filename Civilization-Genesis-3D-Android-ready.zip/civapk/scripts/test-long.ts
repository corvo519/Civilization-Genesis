import { createGame, simStepYear, snapshotCivs, worldStats } from "../src/game/simulation";
const { G } = createGame(777);
const kinds: Record<string, number> = {};
for (let y = 0; y < 3000; y++) {
  const r = simStepYear(G);
  for (const e of r.events) kinds[e.kind] = (kinds[e.kind] ?? 0) + 1;
  if (y === 1500 || y === 2999) {
    console.log(`Year ${G.year}:`, JSON.stringify(worldStats(G)));
    console.log("  civs:", snapshotCivs(G).map(c=>`${c.name} e${c.era} p${(c.pop/1000).toFixed(1)}k t${c.territorySize} c${c.citiesCount}`).join(" | "));
  }
}
console.log("Event totals over 3000y:", kinds);
