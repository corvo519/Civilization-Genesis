import { createGame, simStepYear, snapshotCivs, worldStats, applyTool, impactMeteor } from "../src/game/simulation";

const { G, events } = createGame(12345);
console.log("Genesis events:", events.length);
console.log("Initial civs:", G.civs.length, "cities:", G.cities.length);

let allEvents = [...events];
for (let y = 0; y < 800; y++) {
  const r = simStepYear(G);
  allEvents.push(...r.events);
}
const stats = worldStats(G);
console.log("Year:", G.year, "Stats:", JSON.stringify(stats));
console.log("Civs alive:", snapshotCivs(G).map((c) => `${c.name} (era ${c.era}, pop ${c.pop}, terr ${c.territorySize}, cities ${c.citiesCount})`));
console.log("Wars:", G.wars.length, "Battles:", G.battles.length);
console.log("Events sample:");
for (const e of allEvents.slice(-14)) console.log(`  [${e.year}] (${e.kind}) ${e.text}`);
const kinds = new Set(allEvents.map((e) => e.kind));
console.log("Event kinds seen:", [...kinds].join(", "));

// god tools smoke test
const t = applyTool(G, "volcano", 48, 48, 4);
console.log("Volcano events:", t.events.map((e) => e.text));
const t2 = applyTool(G, "meteor", 40, 60, 4);
console.log("Meteor scheduled, fx:", G.fx.length);
const fx = G.fx[G.fx.length - 1];
const imp = impactMeteor(G, fx.id);
console.log("Impact events:", imp.events.map((e) => e.text));
applyTool(G, "mountain", 30, 30, 5);
applyTool(G, "ocean", 70, 70, 5);
applyTool(G, "river", 50, 20, 4);
applyTool(G, "forest", 60, 40, 5);
applyTool(G, "resource", 44, 44, 5);
applyTool(G, "bless", snapshotCivs(G)[0] ? snapshotCivs(G)[0].capital !== -1 ? (G.cities.find((c) => c.id === snapshotCivs(G)[0].capital)?.tile ?? 100) % 96 : 50 : 50, 50, 4);
for (let y = 0; y < 60; y++) simStepYear(G);
console.log("After tools year:", G.year, "civs:", worldStats(G));
console.log("OK");
