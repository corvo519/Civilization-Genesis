import { generateWorld } from "../src/game/world";
import { W, H, CAT_WATER, CAT_SAND, CAT_GRASS, CAT_FOREST, CAT_ROCK, CAT_SNOW } from "../src/game/types";
for (const seed of [1, 42, 999, 2024]) {
  const w = generateWorld(seed);
  const counts = [0, 0, 0, 0, 0, 0];
  let rivers = 0, res = 0, maxH = 0;
  for (let i = 0; i < W * H; i++) {
    counts[w.cat[i]]++;
    if (w.river[i]) rivers++;
    if (w.res[i]) res++;
    if (w.height[i] > maxH) maxH = w.height[i];
  }
  const tot = W * H;
  console.log(
    `seed ${seed}: water ${(counts[CAT_WATER] / tot * 100).toFixed(0)}% sand ${(counts[CAT_SAND] / tot * 100).toFixed(0)}% grass ${(counts[CAT_GRASS] / tot * 100).toFixed(0)}% forest ${(counts[CAT_FOREST] / tot * 100).toFixed(0)}% rock ${(counts[CAT_ROCK] / tot * 100).toFixed(0)}% snow ${(counts[CAT_SNOW] / tot * 100).toFixed(0)}% | rivers ${rivers}t res ${res} maxH ${maxH.toFixed(2)}`
  );
}
