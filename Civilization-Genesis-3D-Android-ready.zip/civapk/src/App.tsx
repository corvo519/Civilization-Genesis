import { useEffect, useRef } from "react";
import { Scene } from "./components/Scene";
import { TitleScreen } from "./components/ui/TitleScreen";
import { TopBar, Toolbar, HelpOverlay, GameHints, TOOLS } from "./components/ui/HUD";
import { CivPanel } from "./components/ui/CivPanel";
import { EventLog } from "./components/ui/EventLog";
import { Minimap } from "./components/ui/Minimap";
import { useStore } from "./game/store";

function useShortcuts() {
  const lastSpeed = useRef(1);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.repeat) return;
      const s = useStore.getState();
      if (s.phase !== "game") return;
      if (e.code === "Space") {
        e.preventDefault();
        if (s.speed === 0) s.setSpeed(lastSpeed.current || 1);
        else {
          lastSpeed.current = s.speed;
          s.setSpeed(0);
        }
      } else if (e.code === "Escape") {
        if (s.helpOpen) s.toggleHelp();
        else s.selectCiv(null);
      } else if (e.code === "KeyH") {
        s.toggleHelp();
      } else if (e.code.startsWith("Digit")) {
        const n = Number(e.code.slice(5));
        if (n >= 1 && n <= TOOLS.length) s.setTool(TOOLS[n - 1].id);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
}

export default function App() {
  const phase = useStore((s) => s.phase);
  useShortcuts();

  return (
    <div className="relative h-full w-full select-none overflow-hidden bg-[#060b16]">
      {phase === "title" ? (
        <TitleScreen />
      ) : (
        <>
          <Scene />
          <TopBar />
          <Toolbar />
          <CivPanel />
          <EventLog />
          <Minimap />
          <GameHints />
          <HelpOverlay />
        </>
      )}
    </div>
  );
}
