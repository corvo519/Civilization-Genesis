import { useEffect, useMemo } from "react";
import * as THREE from "three";
import { useStore, getG } from "../game/store";
import { W, H, HG, CAT_FOREST, RES_GOLD, RES_IRON, RES_GEM } from "../game/types";

const MAX_TREES = 5200;
const MAX_RES = 700;

const hash = (i: number, k: number) => {
  const x = Math.sin(i * 127.1 + k * 311.7) * 43758.5453;
  return x - Math.floor(x);
};

const RES_DEFS: { type: number; color: string; emissive: number }[] = [
  { type: RES_GOLD, color: "#f2b32a", emissive: 0.55 },
  { type: RES_IRON, color: "#aab4c4", emissive: 0.05 },
  { type: RES_GEM, color: "#31d8c8", emissive: 0.5 },
];

export function Nature() {
  const natureVer = useStore((s) => s.versions.nature);
  const terrainVer = useStore((s) => s.versions.terrain);

  const trunkGeo = useMemo(() => new THREE.CylinderGeometry(0.045, 0.075, 0.3, 5), []);
  const canopyGeo = useMemo(() => new THREE.ConeGeometry(0.26, 0.62, 6), []);
  const trunkMat = useMemo(() => new THREE.MeshStandardMaterial({ color: "#5f4227", roughness: 1 }), []);
  const canopyMat = useMemo(() => new THREE.MeshStandardMaterial({ roughness: 0.9, flatShading: true }), []);
  const resGeo = useMemo(() => new THREE.OctahedronGeometry(0.17, 0), []);

  const trunks = useMemo(() => {
    const m = new THREE.InstancedMesh(trunkGeo, trunkMat, MAX_TREES);
    m.frustumCulled = false;
    m.count = 0;
    return m;
  }, [trunkGeo, trunkMat]);
  const canopies = useMemo(() => {
    const m = new THREE.InstancedMesh(canopyGeo, canopyMat, MAX_TREES);
    m.frustumCulled = false;
    m.count = 0;
    return m;
  }, [canopyGeo, canopyMat]);
  const resMeshes = useMemo(
    () =>
      RES_DEFS.map((d) => {
        const mesh = new THREE.InstancedMesh(
          resGeo,
          new THREE.MeshStandardMaterial({
            color: d.color,
            emissive: d.color,
            emissiveIntensity: d.emissive,
            roughness: 0.35,
            flatShading: true,
          }),
          MAX_RES
        );
        mesh.frustumCulled = false;
        mesh.count = 0;
        return { def: d, mesh };
      }),
    [resGeo]
  );

  const tmpO = useMemo(() => new THREE.Object3D(), []);
  const tmpC = useMemo(() => new THREE.Color(), []);

  useEffect(() => {
    const G = getG();
    if (!G) return;
    const w = G.world;
    let ti = 0;
    for (let i = 0; i < W * H && ti < MAX_TREES; i++) {
      if (!w.forest[i] || w.cat[i] !== CAT_FOREST || w.city[i] >= 0) continue;
      const x = i % W, z = Math.floor(i / W);
      const baseY = w.height[i] * HG;
      const treesHere = 2;
      for (let k = 0; k < treesHere && ti < MAX_TREES; k++) {
        const jx = (hash(i, k * 2) - 0.5) * 0.72;
        const jz = (hash(i, k * 2 + 1) - 0.5) * 0.72;
        const s = 0.75 + hash(i, k + 40) * 0.6;
        const wx = x - W / 2 + 0.5 + jx;
        const wz = z - H / 2 + 0.5 + jz;
        tmpO.position.set(wx, baseY + 0.13 * s, wz);
        tmpO.scale.setScalar(s);
        tmpO.rotation.set(0, hash(i, k + 80) * Math.PI, 0);
        tmpO.updateMatrix();
        trunks.setMatrixAt(ti, tmpO.matrix);
        tmpO.position.set(wx, baseY + (0.3 + 0.31) * s, wz);
        tmpO.updateMatrix();
        canopies.setMatrixAt(ti, tmpO.matrix);
        const g = 0.75 + hash(i, k + 120) * 0.45;
        tmpC.setRGB(0.22 * g + 0.04, 0.48 * g + 0.08, 0.2 * g + 0.04);
        canopies.setColorAt(ti, tmpC);
        ti++;
      }
    }
    trunks.count = ti;
    canopies.count = ti;
    trunks.instanceMatrix.needsUpdate = true;
    canopies.instanceMatrix.needsUpdate = true;
    if (canopies.instanceColor) canopies.instanceColor.needsUpdate = true;

    // resources
    const counts: Record<number, number> = { [RES_GOLD]: 0, [RES_IRON]: 0, [RES_GEM]: 0 };
    for (let i = 0; i < W * H; i++) {
      const r = w.res[i];
      if (!r) continue;
      const mesh = resMeshes.find((m) => m.def.type === r);
      if (!mesh) continue;
      const ci = counts[r];
      if (ci >= MAX_RES) continue;
      const x = i % W, z = Math.floor(i / W);
      tmpO.position.set(
        x - W / 2 + 0.5 + (hash(i, 3) - 0.5) * 0.4,
        w.height[i] * HG + 0.2,
        z - H / 2 + 0.5 + (hash(i, 5) - 0.5) * 0.4
      );
      tmpO.scale.setScalar(0.8 + hash(i, 7) * 0.5);
      tmpO.rotation.set(0, hash(i, 9) * Math.PI, 0);
      tmpO.updateMatrix();
      mesh.mesh.setMatrixAt(ci, tmpO.matrix);
      counts[r] = ci + 1;
    }
    for (const m of resMeshes) {
      m.mesh.count = counts[m.def.type];
      m.mesh.instanceMatrix.needsUpdate = true;
    }
  }, [natureVer, terrainVer, trunks, canopies, resMeshes, tmpO, tmpC]);

  useEffect(
    () => () => {
      trunks.dispose();
      canopies.dispose();
      resMeshes.forEach((m) => { m.mesh.dispose(); (m.mesh.material as THREE.Material).dispose(); });
      trunkGeo.dispose(); canopyGeo.dispose(); trunkMat.dispose(); canopyMat.dispose(); resGeo.dispose();
    },
    [trunks, canopies, resMeshes, trunkGeo, canopyGeo, trunkMat, canopyMat, resGeo]
  );

  return (
    <group>
      <primitive object={trunks} castShadow receiveShadow={false} />
      <primitive object={canopies} castShadow />
      {resMeshes.map((m) => (
        <primitive key={m.def.type} object={m.mesh} />
      ))}
    </group>
  );
}
