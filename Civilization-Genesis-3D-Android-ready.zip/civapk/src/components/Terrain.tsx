import { useEffect, useMemo, useRef, useCallback } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import type { ThreeEvent } from "@react-three/fiber";
import { useStore, getG } from "../game/store";
import { W, H, idx, HG, SEA } from "../game/types";
import { tileColor } from "../game/world";

export function buildTerrainGeometry(): THREE.BufferGeometry | null {
  const G = getG();
  if (!G) return null;
  const w = G.world;
  const cols = W - 1, rows = H - 1;
  const pos = new Float32Array(cols * rows * 6 * 3);
  const col = new Float32Array(cols * rows * 6 * 3);
  let p = 0;
  const vh = (x: number, z: number) => w.height[idx(x, z)] * HG;
  const pushV = (x: number, y: number, z: number, c: [number, number, number]) => {
    pos[p] = x; pos[p + 1] = y; pos[p + 2] = z;
    col[p] = c[0]; col[p + 1] = c[1]; col[p + 2] = c[2];
    p += 3;
  };
  for (let z = 0; z < rows; z++) {
    for (let x = 0; x < cols; x++) {
      const i = idx(x, z);
      const c = tileColor(w, i, x, z);
      const x0 = x - W / 2, x1 = x + 1 - W / 2;
      const z0 = z - H / 2, z1 = z + 1 - H / 2;
      const y00 = vh(x, z), y10 = vh(x + 1, z), y01 = vh(x, z + 1), y11 = vh(x + 1, z + 1);
      pushV(x0, y00, z0, c);
      pushV(x0, y01, z1, c);
      pushV(x1, y11, z1, c);
      pushV(x0, y00, z0, c);
      pushV(x1, y11, z1, c);
      pushV(x1, y10, z0, c);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  g.setAttribute("color", new THREE.BufferAttribute(col, 3));
  g.computeVertexNormals();
  return g;
}

const TOOL_RING_COLOR: Record<string, string> = {
  observe: "#e8f4ff",
  mountain: "#c9a15a",
  ocean: "#4aa8d8",
  river: "#5bd0f0",
  forest: "#6fce62",
  resource: "#f2d06b",
  bless: "#ffd76b",
  volcano: "#ff6b3d",
  meteor: "#ff5252",
};

export function Terrain() {
  const terrainVer = useStore((s) => s.versions.terrain);
  const geom = useMemo(() => buildTerrainGeometry(), [terrainVer]);
  useEffect(() => () => { geom?.dispose(); }, [geom]);

  const meshRef = useRef<THREE.Mesh>(null);
  const ringRef = useRef<THREE.Mesh>(null);
  const ringMatRef = useRef<THREE.MeshBasicMaterial>(null);
  const downAt = useRef<{ x: number; y: number } | null>(null);
  const hoverTile = useRef<{ x: number; z: number } | null>(null);

  const applyAtEvent = useCallback((e: ThreeEvent<PointerEvent>) => {
    const tx = Math.round(e.point.x + W / 2 - 0.5);
    const tz = Math.round(e.point.z + H / 2 - 0.5);
    if (tx < 1 || tz < 1 || tx > W - 3 || tz > H - 3) return;
    useStore.getState().applyToolAt(tx, tz);
  }, []);

  const updateRing = useCallback((e: ThreeEvent<PointerEvent>) => {
    const tx = Math.round(e.point.x + W / 2 - 0.5);
    const tz = Math.round(e.point.z + H / 2 - 0.5);
    hoverTile.current = { x: tx, z: tz };
    const G = getG();
    if (ringRef.current && G && tx >= 1 && tz >= 1 && tx <= W - 3 && tz <= H - 3) {
      const y = G.world.height[idx(tx, tz)] * HG;
      ringRef.current.position.set(tx - W / 2 + 0.5, Math.max(y, SEA * HG) + 0.3, tz - H / 2 + 0.5);
      ringRef.current.visible = true;
    }
  }, []);

  useFrame(({ clock }) => {
    const s = useStore.getState();
    const ring = ringRef.current;
    if (!ring) return;
    ring.scale.setScalar(s.brush * (1 + Math.sin(clock.elapsedTime * 3) * 0.03));
    if (ringMatRef.current) ringMatRef.current.color.set(TOOL_RING_COLOR[s.tool] ?? "#ffffff");
    if (s.tool === "bless" || s.tool === "volcano" || s.tool === "meteor")
      ring.scale.setScalar(s.tool === "bless" ? 2 : 4);
  });

  return (
    <group>
      {geom && (
        <mesh
          ref={meshRef}
          geometry={geom}
          receiveShadow
          castShadow
          onPointerMove={(e) => {
            updateRing(e);
            if (e.buttons === 1 && downAt.current) applyAtEvent(e);
          }}
          onPointerDown={(e) => {
            if (e.button !== 0) return;
            downAt.current = { x: e.clientX ?? 0, y: e.clientY ?? 0 };
            if (useStore.getState().tool !== "observe") applyAtEvent(e);
            e.stopPropagation();
          }}
          onPointerOut={() => {
            if (ringRef.current) ringRef.current.visible = false;
            downAt.current = null;
          }}
          onPointerUp={(e) => {
            if (e.button !== 0) { downAt.current = null; return; }
            const d = downAt.current;
            downAt.current = null;
            const s = useStore.getState();
            if (s.tool !== "observe" || !d) return;
            const moved = Math.hypot((e.clientX ?? 0) - d.x, (e.clientY ?? 0) - d.y);
            if (moved > 6) return;
            const tx = Math.round(e.point.x + W / 2 - 0.5);
            const tz = Math.round(e.point.z + H / 2 - 0.5);
            const G = getG();
            if (!G || tx < 1 || tz < 1 || tx > W - 3 || tz > H - 3) return;
            const i = idx(tx, tz);
            const civId = G.world.owner[i] >= 0
              ? G.world.owner[i]
              : G.world.city[i] >= 0
                ? G.cities.find((c) => c.id === G.world.city[i])?.civ ?? -1
                : -1;
            s.selectCiv(civId >= 0 ? civId : null, false);
          }}
        >
          <meshStandardMaterial vertexColors roughness={0.95} metalness={0.02} />
        </mesh>
      )}
      {/* brush cursor ring */}
      <mesh ref={ringRef} rotation={[-Math.PI / 2, 0, 0]} visible={false} renderOrder={5}>
        <ringGeometry args={[0.86, 1, 48]} />
        <meshBasicMaterial
          ref={ringMatRef}
          color="#ffd76b"
          transparent
          opacity={0.75}
          depthWrite={false}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}
