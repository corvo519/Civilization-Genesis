import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { Html } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useStore, getG } from "../game/store";
import { getCapitalPos } from "../game/simulation";
import { mulberry32 } from "../game/rng";
import { W, H, HG, type City, type Civ } from "../game/types";

const MAX_BODIES = 2400;
const MAX_ROOFS = 1800;

const ERA_BODY = ["#b99a6b", "#d8c9a3", "#9aa3ad", "#8d6857", "#9fd8f0"];
const ERA_ROOF = ["#7a5c33", "#b4583a", "#525c6b", "#3f4754", "#bfeaff"];
const ERA_HEIGHT = [0.24, 0.32, 0.44, 0.62, 1.0];

interface LabelDef {
  key: string;
  x: number; y: number; z: number;
  name: string;
  color: string;
  blessed: boolean;
  capital: boolean;
}

function rebuild(
  bodies: THREE.InstancedMesh,
  roofs: THREE.InstancedMesh,
  tmpO: THREE.Object3D,
  tmpC: THREE.Color
) {
  const G = getG();
  if (!G) return;
  let bi = 0, ri = 0;
  const civById = new Map<number, Civ>(G.civs.map((c) => [c.id, c]));

  const addBody = (x: number, y: number, z: number, w: number, h: number, d: number, color: string, tint: number) => {
    if (bi >= MAX_BODIES) return;
    tmpO.position.set(x, y + h / 2, z);
    tmpO.scale.set(w, h, d);
    tmpO.rotation.set(0, 0, 0);
    tmpO.updateMatrix();
    bodies.setMatrixAt(bi, tmpO.matrix);
    tmpC.set(color).multiplyScalar(tint);
    bodies.setColorAt(bi, tmpC);
    bi++;
  };
  const addRoof = (x: number, y: number, z: number, r: number, h: number, color: string, tint: number) => {
    if (ri >= MAX_ROOFS) return;
    tmpO.position.set(x, y + h / 2, z);
    tmpO.scale.set(r, h, r);
    tmpO.rotation.set(0, 0, 0);
    tmpO.updateMatrix();
    roofs.setMatrixAt(ri, tmpO.matrix);
    tmpC.set(color).multiplyScalar(tint);
    roofs.setColorAt(ri, tmpC);
    ri++;
  };

  for (const city of G.cities) {
    const civ = civById.get(city.civ);
    const era = civ ? civ.era : 0;
    const rnd = mulberry32(city.id * 7919 + 17);
    const cx = (city.tile % W) - W / 2 + 0.5;
    const cz = Math.floor(city.tile / W) - H / 2 + 0.5;
    const gy = G.world.height[city.tile] * HG;
    const count = Math.min(16, 3 + city.level * 3 + (city.capital ? 2 : 0));
    const clusterR = 0.3 + city.level * 0.06;

    for (let b = 0; b < count; b++) {
      const ang = rnd() * Math.PI * 2;
      const rad = Math.sqrt(rnd()) * clusterR;
      const x = cx + Math.cos(ang) * rad;
      const z = cz + Math.sin(ang) * rad;
      const tint = 0.85 + rnd() * 0.3;
      const baseH = ERA_HEIGHT[era] * (0.7 + rnd() * 0.8) * (0.8 + city.level * 0.12);
      const size = 0.16 + rnd() * 0.1;
      addBody(x, gy - 0.05, z, size, baseH, size, ERA_BODY[era], tint);
      if (era <= 2) addRoof(x, gy - 0.05 + baseH, z, size * 0.85, 0.16 + rnd() * 0.1, ERA_ROOF[era], tint);
      if (era === 3 && rnd() < 0.5)
        addBody(x + size * 0.2, gy - 0.05 + baseH, z, size * 0.22, 0.3 + rnd() * 0.25, size * 0.22, "#3a4150", 1);
    }

    // capital centerpiece
    if (city.capital) {
      if (era <= 2) {
        const keepH = ERA_HEIGHT[era] * 2.2;
        addBody(cx, gy - 0.05, cz, 0.3, keepH, 0.3, era === 2 ? "#8a93a3" : ERA_BODY[era], 1.05);
        addRoof(cx, gy - 0.05 + keepH, cz, 0.24, 0.3, ERA_ROOF[era], 1.05);
        if (era === 2) {
          // corner turrets
          for (let k = 0; k < 4; k++) {
            const ang = (k / 4) * Math.PI * 2 + Math.PI / 4;
            const x = cx + Math.cos(ang) * 0.42;
            const z = cz + Math.sin(ang) * 0.42;
            addBody(x, gy - 0.05, z, 0.12, 0.55, 0.12, "#8891a1", 1);
            addRoof(x, gy + 0.5, z, 0.11, 0.2, "#525c6b", 1);
          }
          // curtain wall ring
          for (let k = 0; k < 10; k++) {
            const ang = (k / 10) * Math.PI * 2;
            addBody(cx + Math.cos(ang) * 0.62, gy - 0.04, cz + Math.sin(ang) * 0.62, 0.18, 0.16, 0.18, "#7d8695", 0.95);
          }
        }
      } else {
        // industrial/tech main tower
        const h = ERA_HEIGHT[era] * 2.6;
        addBody(cx, gy - 0.05, cz, 0.34, h, 0.34, era === 4 ? "#7be3ff" : "#6b5a4e", 1.1);
        if (era === 4) addBody(cx, gy - 0.05 + h, cz, 0.05, 0.5, 0.05, "#e8fbff", 1.2);
      }
    }
  }

  bodies.count = bi;
  roofs.count = ri;
  bodies.instanceMatrix.needsUpdate = true;
  roofs.instanceMatrix.needsUpdate = true;
  if (bodies.instanceColor) bodies.instanceColor.needsUpdate = true;
  if (roofs.instanceColor) roofs.instanceColor.needsUpdate = true;
}

export function Cities() {
  const citiesVer = useStore((s) => s.versions.cities);
  const terrainVer = useStore((s) => s.versions.terrain);
  const civs = useStore((s) => s.civs);

  const bodyGeo = useMemo(() => new THREE.BoxGeometry(1, 1, 1), []);
  const roofGeo = useMemo(() => new THREE.ConeGeometry(0.71, 1, 4), []);
  const bodyMat = useMemo(
    () => new THREE.MeshStandardMaterial({ roughness: 0.85, flatShading: true }),
    []
  );
  const roofMat = useMemo(
    () => new THREE.MeshStandardMaterial({ roughness: 0.9, flatShading: true }),
    []
  );
  const bodies = useMemo(() => {
    const m = new THREE.InstancedMesh(bodyGeo, bodyMat, MAX_BODIES);
    m.frustumCulled = false;
    m.count = 0;
    return m;
  }, [bodyGeo, bodyMat]);
  const roofs = useMemo(() => {
    const m = new THREE.InstancedMesh(roofGeo, roofMat, MAX_ROOFS);
    m.frustumCulled = false;
    m.count = 0;
    return m;
  }, [roofGeo, roofMat]);

  const tmpO = useMemo(() => new THREE.Object3D(), []);
  const tmpC = useMemo(() => new THREE.Color(), []);

  useEffect(() => {
    rebuild(bodies, roofs, tmpO, tmpC);
  }, [citiesVer, terrainVer, bodies, roofs, tmpO, tmpC]);

  useEffect(
    () => () => {
      bodies.dispose(); roofs.dispose();
      bodyGeo.dispose(); roofGeo.dispose(); bodyMat.dispose(); roofMat.dispose();
    },
    [bodies, roofs, bodyGeo, roofGeo, bodyMat, roofMat]
  );

  /* capital labels */
  const labels = useMemo<LabelDef[]>(() => {
    const G = getG();
    if (!G) return [];
    const defs: LabelDef[] = [];
    for (const snap of civs) {
      const capId = snap.capital;
      const city: City | undefined = G.cities.find((c) => c.id === capId);
      const pos = getCapitalPos(G, snap.id);
      if (!pos) continue;
      const tile = city ? city.tile : 0;
      const gy = city ? G.world.height[tile] * HG : 0;
      defs.push({
        key: `c${snap.id}`,
        x: pos.x, y: gy + 2.1, z: pos.z,
        name: city ? `${city.name}` : snap.name,
        color: snap.color,
        blessed: snap.blessed > 0,
        capital: true,
      });
    }
    return defs;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [civs, citiesVer, terrainVer]);

  const ringRefs = useRef<THREE.Mesh[]>([]);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    ringRefs.current.forEach((r, i) => {
      if (!r) return;
      r.rotation.z = t * 0.7 + i;
      const s = 1 + Math.sin(t * 2.2 + i) * 0.12;
      r.scale.setScalar(s);
    });
  });

  return (
    <group>
      <primitive object={bodies} castShadow />
      <primitive object={roofs} castShadow />
      {labels.map((l, i) => (
        <group key={l.key} position={[l.x, l.y, l.z]}>
          {l.blessed && (
            <mesh
              ref={(m) => { if (m) ringRefs.current[i] = m; }}
              rotation={[-Math.PI / 2, 0, 0]}
              position={[0, -1.5, 0]}
            >
              <torusGeometry args={[1.1, 0.06, 8, 36]} />
              <meshStandardMaterial color="#ffd76b" emissive="#ffd76b" emissiveIntensity={2.2} />
            </mesh>
          )}
          <Html center distanceFactor={62} zIndexRange={[20, 0]} style={{ pointerEvents: "none" }}>
            <div
              className="flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-[10px] font-semibold tracking-wide"
              style={{
                background: "rgba(8,12,24,0.62)",
                border: `1px solid ${l.color}66`,
                boxShadow: "0 4px 14px rgba(0,0,0,0.4)",
                color: "#fff",
                backdropFilter: "blur(6px)",
              }}
            >
              <span
                className="inline-block h-1.5 w-1.5 rounded-full"
                style={{ background: l.color, boxShadow: `0 0 6px ${l.color}` }}
              />
              {l.name}
            </div>
          </Html>
        </group>
      ))}
    </group>
  );
}
