import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { seaY } from "../game/types";

const WATER_VERT = /* glsl */ `
uniform float uTime;
varying vec2 vUv;
varying float vWave;
varying vec3 vPos;
void main() {
  vUv = uv;
  vec3 p = position;
  float w = sin(p.x * 0.32 + uTime * 1.15) * 0.5
          + sin(p.y * 0.27 - uTime * 0.85) * 0.5
          + sin((p.x + p.y) * 0.13 + uTime * 0.55) * 0.35;
  vWave = w;
  vec3 np = vec3(p.x, p.y, p.z + w * 0.1);
  vPos = np;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(np, 1.0);
}
`;

const WATER_FRAG = /* glsl */ `
uniform float uTime;
varying vec2 vUv;
varying float vWave;
void main() {
  vec3 deep = vec3(0.045, 0.29, 0.47);
  vec3 light = vec3(0.24, 0.66, 0.83);
  float m = 0.5 + vWave * 0.28;
  vec3 col = mix(deep, light, m);
  // slow moving foam sparkle bands
  float band = sin(vUv.x * 300.0 + uTime * 0.8 + sin(vUv.y * 260.0 - uTime * 0.6) * 2.0);
  float foam = smoothstep(0.92, 1.0, band) * 0.35;
  col += foam * vec3(0.75, 0.9, 0.95);
  gl_FragColor = vec4(col, 0.9);
}
`;

export function Water() {
  const matRef = useRef<THREE.ShaderMaterial>(null);
  const uniforms = useMemo(
    () => ({ uTime: { value: 0 } }),
    []
  );
  useFrame((_, dt) => {
    if (matRef.current) matRef.current.uniforms.uTime.value += dt;
  });
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, seaY, 0]} renderOrder={2}>
        <planeGeometry args={[420, 420, 64, 64]} />
        <shaderMaterial
          ref={matRef}
          vertexShader={WATER_VERT}
          fragmentShader={WATER_FRAG}
          uniforms={uniforms}
          transparent
          depthWrite={false}
        />
      </mesh>
      {/* abyss floor under everything */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, seaY - 1.6, 0]}>
        <planeGeometry args={[500, 500]} />
        <meshStandardMaterial color="#0a3049" roughness={1} />
      </mesh>
    </group>
  );
}
