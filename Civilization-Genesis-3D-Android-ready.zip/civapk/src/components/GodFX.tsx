import { useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { useStore, getG } from "../game/store";
import { HG, tileToWorld, type FxItem } from "../game/types";

/* ------------------------------------------------ Meteor */
function MeteorFx({ fx }: { fx: FxItem }) {
  const meteorImpact = useStore((s) => s.meteorImpact);
  const removeFx = useStore((s) => s.removeFx);
  const headRef = useRef<THREE.Mesh>(null);
  const lightRef = useRef<THREE.PointLight>(null);
  const ringRef = useRef<THREE.Mesh>(null);
  const [hitAt, setHitAt] = useState<number | null>(null);
  const start = useMemo(() => new THREE.Vector3(fx.x + 30, fx.y + 36, fx.z + 14), [fx.x, fx.y, fx.z]);
  const target = useMemo(() => new THREE.Vector3(fx.x, fx.y, fx.z), [fx.x, fx.y, fx.z]);
  const trailGeom = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(12 * 3), 3));
    return g;
  }, []);
  const trailLine = useMemo(
    () =>
      new THREE.Line(
        trailGeom,
        new THREE.LineBasicMaterial({ color: "#ffb36b", transparent: true, opacity: 0.85 })
      ),
    [trailGeom]
  );

  useFrame(() => {
    const now = performance.now();
    const p = Math.min(1, (now - fx.t0) / fx.dur);
    if (p < 1) {
      const t = p * p;
      if (headRef.current) headRef.current.position.copy(start).lerp(target, t);
      const attr = trailGeom.getAttribute("position") as THREE.BufferAttribute;
      for (let i = 0; i < 12; i++) {
        const back = Math.max(0, t - i * 0.045);
        attr.setXYZ(
          i,
          start.x + (target.x - start.x) * back,
          start.y + (target.y - start.y) * back,
          start.z + (target.z - start.z) * back
        );
      }
      attr.needsUpdate = true;
    } else if (hitAt === null) {
      setHitAt(now);
      meteorImpact(fx.id);
      if (headRef.current) headRef.current.visible = false;
      trailLine.visible = false;
    } else {
      const e = (now - hitAt) / 700;
      if (lightRef.current) lightRef.current.intensity = Math.max(0, 90 * (1 - e));
      if (ringRef.current) {
        ringRef.current.scale.setScalar(1 + e * 14);
        (ringRef.current.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.8 - e);
      }
      if (e > 1.2) removeFx(fx.id);
    }
  });

  return (
    <group>
      <mesh ref={headRef} position={start.toArray()}>
        <sphereGeometry args={[0.5, 12, 10]} />
        <meshStandardMaterial color="#ffd9a0" emissive="#ff8433" emissiveIntensity={4} />
      </mesh>
      <primitive object={trailLine} />
      {hitAt !== null && (
        <>
          <pointLight ref={lightRef} position={[fx.x, fx.y + 2, fx.z]} color="#ff9a4d" intensity={90} distance={26} />
          <mesh ref={ringRef} position={[fx.x, fx.y + 0.3, fx.z]} rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[0.2, 0.42, 32]} />
            <meshBasicMaterial color="#ffb26b" transparent opacity={0.8} depthWrite={false} side={THREE.DoubleSide} />
          </mesh>
          <mesh position={[fx.x, fx.y + 0.4, fx.z]}>
            <sphereGeometry args={[1.4, 16, 12]} />
            <meshStandardMaterial color="#ffefe0" emissive="#ff9440" emissiveIntensity={3.2} transparent opacity={0.9} />
          </mesh>
        </>
      )}
    </group>
  );
}

/* ------------------------------------------------ Eruption */
function EruptionFx({ fx }: { fx: FxItem }) {
  const removeFx = useStore((s) => s.removeFx);
  const N_SMOKE = 42;
  const N_EMBER = 26;
  const smokeGeo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const pos = new Float32Array(N_SMOKE * 3);
    for (let i = 0; i < N_SMOKE; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 1.4;
      pos[i * 3 + 1] = Math.random() * 9;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 1.4;
    }
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    return g;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const emberGeo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const pos = new Float32Array(N_EMBER * 3);
    for (let i = 0; i < N_EMBER; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 1;
      pos[i * 3 + 1] = Math.random() * 6;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 1;
    }
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    return g;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const smokeMat = useRef<THREE.PointsMaterial>(null);

  useFrame((_, dt) => {
    const p = (performance.now() - fx.t0) / fx.dur;
    if (p >= 1) { removeFx(fx.id); return; }
    const sAttr = smokeGeo.getAttribute("position") as THREE.BufferAttribute;
    for (let i = 0; i < N_SMOKE; i++) {
      let y = sAttr.getY(i) + dt * (2.2 + (i % 4) * 0.5);
      if (y > 10) y = 0;
      sAttr.setY(i, y);
      sAttr.setX(i, sAttr.getX(i) + dt * 0.25);
    }
    sAttr.needsUpdate = true;
    const eAttr = emberGeo.getAttribute("position") as THREE.BufferAttribute;
    for (let i = 0; i < N_EMBER; i++) {
      let y = eAttr.getY(i) + dt * (4 + (i % 3) * 1.4);
      if (y > 6) y = 0;
      eAttr.setY(i, y);
      eAttr.setX(i, eAttr.getX(i) + (Math.random() - 0.5) * dt * 2);
    }
    eAttr.needsUpdate = true;
    if (smokeMat.current) smokeMat.current.opacity = p < 0.75 ? 0.65 : 0.65 * (1 - (p - 0.75) / 0.25);
  });

  return (
    <group position={[fx.x, fx.y + 0.4, fx.z]}>
      <points geometry={smokeGeo}>
        <pointsMaterial ref={smokeMat} color="#4a4038" size={0.75} sizeAttenuation transparent opacity={0.65} depthWrite={false} />
      </points>
      <points geometry={emberGeo}>
        <pointsMaterial color="#ff8c3b" size={0.2} sizeAttenuation transparent opacity={0.95} depthWrite={false} />
      </points>
      <pointLight color="#ff6a2a" intensity={40} distance={22} position={[0, 2, 0]} />
    </group>
  );
}

/* ------------------------------------------------ Lava glow on active volcanoes */
function VolcanoGlows() {
  const year = useStore((s) => s.year);
  const fxVer = useStore((s) => s.fxVer);
  const G = getG();
  void fxVer;
  if (!G) return null;
  const items = G.world.volcanoes
    .map((v) => ({ ...v, age: Math.max(0, year - v.born) }))
    .filter((v) => v.age < 10)
    .slice(-4);
  return (
    <group>
      {items.map((v, i) => {
        const p = tileToWorld(v.tile);
        const y = G.world.height[v.tile] * HG;
        const fade = Math.max(0.15, 1 - v.age / 10);
        return (
          <group key={i} position={[p.x, y + 0.18, p.z]}>
            <mesh rotation={[-Math.PI / 2, 0, 0]}>
              <circleGeometry args={[0.55, 20]} />
              <meshStandardMaterial color="#ff7a2f" emissive="#ff5a1a" emissiveIntensity={2.6 * fade} />
            </mesh>
            {v.age < 6 && <pointLight color="#ff7a30" intensity={26 * fade} distance={15} position={[0, 1.4, 0]} />}
          </group>
        );
      })}
    </group>
  );
}

/* ------------------------------------------------ Bless beam */
function BlessBeam({ fx }: { fx: FxItem }) {
  const removeFx = useStore((s) => s.removeFx);
  const matRef = useRef<THREE.MeshBasicMaterial>(null);
  useFrame(() => {
    const p = (performance.now() - fx.t0) / fx.dur;
    if (p >= 1) { removeFx(fx.id); return; }
    if (matRef.current) matRef.current.opacity = 0.35 * Math.sin(Math.min(1, p) * Math.PI);
  });
  return (
    <group position={[fx.x, fx.y, fx.z]}>
      <mesh position={[0, 14, 0]}>
        <cylinderGeometry args={[0.7, 1.1, 28, 14, 1, true]} />
        <meshBasicMaterial
          ref={matRef}
          color="#ffe9a3"
          transparent
          opacity={0.3}
          side={THREE.DoubleSide}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </mesh>
      <pointLight color="#ffdf8a" intensity={22} distance={16} position={[0, 3, 0]} />
    </group>
  );
}

export function GodFX() {
  const fxVer = useStore((s) => s.fxVer);
  const G = getG();
  const list = G ? G.fx : [];
  void fxVer;
  return (
    <group>
      {list.map((fx) =>
        fx.type === "meteor" ? (
          <MeteorFx key={fx.id} fx={fx} />
        ) : fx.type === "blessfx" ? (
          <BlessBeam key={fx.id} fx={fx} />
        ) : (
          <EruptionFx key={fx.id} fx={fx} />
        )
      )}
      <VolcanoGlows />
    </group>
  );
}
