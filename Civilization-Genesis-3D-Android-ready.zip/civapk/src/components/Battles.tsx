import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Html } from "@react-three/drei";
import { Swords } from "lucide-react";
import { useStore, getG } from "../game/store";
import { tileToWorld, HG, type Battle } from "../game/types";

function BattleFX({ b }: { b: Battle }) {
  const ringRef = useRef<THREE.Mesh>(null);
  const ptsRef = useRef<THREE.Points>(null);
  const seeds = useMemo(() => {
    const arr = new Float32Array(18 * 3);
    for (let i = 0; i < 18; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 0.7;
      arr[i * 3 + 1] = Math.random();
      arr[i * 3 + 2] = (Math.random() - 0.5) * 0.7;
    }
    return arr;
  }, []);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(seeds.slice(), 3));
    return g;
  }, [seeds]);
  const life = useRef(0);

  const G = getG();
  const p = tileToWorld(b.tile);
  const y = (G ? G.world.height[b.tile] * HG : 0) + 0.4;

  useFrame((_, dt) => {
    life.current += dt;
    const t = life.current;
    if (ringRef.current) {
      const s = 0.5 + (t % 0.9) * 1.3;
      ringRef.current.scale.setScalar(s);
      const m = ringRef.current.material as THREE.MeshBasicMaterial;
      m.opacity = Math.max(0, 0.85 - (t % 0.9));
    }
    if (ptsRef.current) {
      const attr = ptsRef.current.geometry.getAttribute("position") as THREE.BufferAttribute;
      for (let i = 0; i < attr.count; i++) {
        let yy = attr.getY(i) + dt * (0.8 + (i % 3) * 0.3);
        if (yy > 1.4) yy = 0.1;
        attr.setY(i, yy);
      }
      attr.needsUpdate = true;
    }
  });

  return (
    <group position={[p.x, y, p.z]}>
      <mesh ref={ringRef} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.32, 0.42, 24]} />
        <meshBasicMaterial color="#ff3b30" transparent opacity={0.8} depthWrite={false} side={THREE.DoubleSide} />
      </mesh>
      <points ref={ptsRef} geometry={geo}>
        <pointsMaterial color="#ff7a45" size={0.16} sizeAttenuation transparent opacity={0.9} depthWrite={false} />
      </points>
      <Html center distanceFactor={70} zIndexRange={[15, 0]} style={{ pointerEvents: "none" }}>
        <div
          className="flex h-6 w-6 items-center justify-center rounded-full animate-pulse-glow"
          style={{
            background: "rgba(120,10,10,0.85)",
            border: "1px solid rgba(255,120,100,0.7)",
            boxShadow: "0 0 16px rgba(255,60,40,0.65)",
          }}
        >
          <Swords size={12} color="#ffd9d2" />
        </div>
      </Html>
    </group>
  );
}

export function Battles() {
  const battles = useStore((s) => s.battles);
  return (
    <group>
      {battles.map((b) => (
        <BattleFX key={b.id} b={b} />
      ))}
    </group>
  );
}
