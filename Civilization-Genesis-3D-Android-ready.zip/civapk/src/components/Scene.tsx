import { useEffect, useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import { EffectComposer, Bloom, Vignette } from "@react-three/postprocessing";
import { useStore, shakeRef } from "../game/store";
import { Terrain } from "./Terrain";
import { Water } from "./Water";
import { Territory } from "./Territory";
import { Nature } from "./Nature";
import { Cities } from "./Cities";
import { Battles } from "./Battles";
import { GodFX } from "./GodFX";
import { SkyDome, Clouds } from "./Atmosphere";

/* Simulation advance loop, tied to frame rate */
function SimLoop() {
  useFrame((_, dt) => {
    useStore.getState().tick(Math.min(dt, 0.12));
  });
  return null;
}

/* Camera helpers: focus-to-point, WASD panning, shake */
function CameraFX() {
  const controls = useThree((s) => s.controls) as unknown as {
    target: THREE.Vector3;
    update: () => void;
  } | null;
  const focusTarget = useRef<THREE.Vector3 | null>(null);
  const lastFocusN = useRef(0);
  const keys = useRef<Set<string>>(new Set());

  useEffect(() => {
    const dn = (e: KeyboardEvent) => keys.current.add(e.code);
    const up = (e: KeyboardEvent) => keys.current.delete(e.code);
    window.addEventListener("keydown", dn);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", dn);
      window.removeEventListener("keyup", up);
    };
  }, []);

  useFrame(({ camera }, dt) => {
    const f = useStore.getState().focus;
    if (f && f.n !== lastFocusN.current) {
      lastFocusN.current = f.n;
      focusTarget.current = new THREE.Vector3(f.x, 4, f.z);
    }
    if (controls && focusTarget.current) {
      const t = focusTarget.current;
      const prevX = controls.target.x, prevZ = controls.target.z;
      controls.target.lerp(t, 1 - Math.exp(-dt * 3));
      camera.position.x += controls.target.x - prevX;
      camera.position.z += controls.target.z - prevZ;
      // ease camera closer
      const dist = camera.position.distanceTo(controls.target);
      if (dist > 55) {
        const dir = camera.position.clone().sub(controls.target).normalize();
        camera.position.add(dir.multiplyScalar(-dt * 30));
      }
      if (controls.target.distanceTo(t) < 0.3) focusTarget.current = null;
    }
    // WASD / arrows panning
    if (controls && keys.current.size > 0) {
      const fwd = new THREE.Vector3().subVectors(controls.target, camera.position);
      fwd.y = 0;
      if (fwd.lengthSq() > 0.001) {
        fwd.normalize();
        const right = new THREE.Vector3(-fwd.z, 0, fwd.x);
        const sp = Math.min(120, Math.max(24, camera.position.distanceTo(controls.target))) * 0.55 * dt;
        const mv = new THREE.Vector3();
        const k = keys.current;
        if (k.has("KeyW") || k.has("ArrowUp")) mv.add(fwd);
        if (k.has("KeyS") || k.has("ArrowDown")) mv.sub(fwd);
        if (k.has("KeyA") || k.has("ArrowLeft")) mv.add(right);
        if (k.has("KeyD") || k.has("ArrowRight")) mv.sub(right);
        if (mv.lengthSq() > 0) {
          mv.normalize().multiplyScalar(sp);
          controls.target.add(mv);
          camera.position.add(mv);
          // clamp
          controls.target.x = Math.max(-58, Math.min(58, controls.target.x));
          controls.target.z = Math.max(-58, Math.min(58, controls.target.z));
        }
      }
    }
    // impact shake
    if (shakeRef.amp > 0.004) {
      camera.position.x += (Math.random() - 0.5) * shakeRef.amp;
      camera.position.y += (Math.random() - 0.5) * shakeRef.amp * 0.55;
      camera.position.z += (Math.random() - 0.5) * shakeRef.amp;
      shakeRef.amp *= Math.exp(-dt * 4.2);
    }
  });
  return null;
}

export function Scene() {
  return (
    <Canvas
      shadows
      dpr={[1, 1.75]}
      camera={{ fov: 42, near: 0.5, far: 900, position: [58, 48, 58] }}
      gl={{ antialias: true, powerPreference: "high-performance" }}
      onCreated={({ gl }) => gl.setClearColor("#9dc2dd")}
      style={{ position: "fixed", inset: 0 }}
    >
      <fog attach="fog" args={["#b9d2e6", 130, 320]} />
      <hemisphereLight args={["#cfe6ff", "#46604f", 0.85]} />
      <directionalLight
        position={[52, 74, 30]}
        intensity={1.85}
        color="#fff0d8"
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-80}
        shadow-camera-right={80}
        shadow-camera-top={80}
        shadow-camera-bottom={-80}
        shadow-camera-far={220}
        shadow-bias={-0.00035}
      />
      <ambientLight intensity={0.12} />

      <SkyDome />
      <Clouds />
      <Water />
      <Terrain />
      <Territory />
      <Nature />
      <Cities />
      <Battles />
      <GodFX />
      <SimLoop />
      <CameraFX />

      <OrbitControls
        makeDefault
        enableDamping
        dampingFactor={0.08}
        minDistance={13}
        maxDistance={175}
        maxPolarAngle={1.34}
        target={[0, 4, 0]}
        ref={(c) => {
          // left mouse is reserved for god tools; rotate with right, pan with middle
          if (c) {
            const mb = (c as unknown as { mouseButtons: Record<string, unknown> }).mouseButtons;
            mb.LEFT = null;
            mb.MIDDLE = THREE.MOUSE.PAN;
            mb.RIGHT = THREE.MOUSE.ROTATE;
          }
        }}
      />

      <EffectComposer multisampling={2}>
        <Bloom intensity={0.52} luminanceThreshold={0.82} luminanceSmoothing={0.24} mipmapBlur />
        <Vignette eskil={false} offset={0.22} darkness={0.58} />
      </EffectComposer>
    </Canvas>
  );
}
