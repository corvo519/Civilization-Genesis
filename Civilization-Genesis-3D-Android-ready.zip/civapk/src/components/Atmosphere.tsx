import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";

const SKY_VERT = /* glsl */ `
varying vec3 vDir;
void main() {
  vDir = normalize(position);
  vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  gl_Position = p.xyww; // pin to far plane
}
`;

const SKY_FRAG = /* glsl */ `
varying vec3 vDir;
void main() {
  vec3 zenith = vec3(0.22, 0.47, 0.78);
  vec3 mid = vec3(0.55, 0.74, 0.9);
  vec3 horizon = vec3(0.86, 0.93, 0.97);
  float h = clamp(vDir.y, 0.0, 1.0);
  vec3 col = mix(horizon, mid, smoothstep(0.0, 0.18, h));
  col = mix(col, zenith, smoothstep(0.18, 0.65, h));
  // warm glow toward the sun
  vec3 sunDir = normalize(vec3(0.55, 0.55, 0.35));
  float s = pow(max(dot(normalize(vDir), sunDir), 0.0), 24.0);
  col += vec3(1.0, 0.85, 0.55) * s * 0.35;
  gl_FragColor = vec4(col, 1.0);
}
`;

export function SkyDome() {
  return (
    <mesh renderOrder={-10} frustumCulled={false}>
      <sphereGeometry args={[380, 24, 16]} />
      <shaderMaterial
        vertexShader={SKY_VERT}
        fragmentShader={SKY_FRAG}
        side={THREE.BackSide}
        depthWrite={false}
      />
    </mesh>
  );
}

/* ---------------- low-poly drifting clouds ---------------- */
interface CloudDef {
  x: number; y: number; z: number;
  speed: number;
  scale: number;
  geom: THREE.BufferGeometry;
}

function makeCloud(seed: number, x: number, y: number, z: number): CloudDef {
  const r = (n: number) => {
    seed = (seed * 9301 + 49297) % 233280;
    return (seed / 233280) * n;
  };
  const parts: THREE.BufferGeometry[] = [];
  const count = 3 + Math.floor(r(3));
  const m = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  for (let i = 0; i < count; i++) {
    const g = new THREE.IcosahedronGeometry(1, 0);
    const sx = 1.6 + r(1.6), sy = 0.72 + r(0.4), sz = 1.1 + r(1.1);
    m.compose(
      new THREE.Vector3((r(1) - 0.5) * 3.4, (r(1) - 0.5) * 0.5, (r(1) - 0.5) * 2.2),
      q,
      new THREE.Vector3(sx, sy, sz)
    );
    g.applyMatrix4(m);
    parts.push(g);
  }
  const geom = mergeGeometries(parts, false)!;
  parts.forEach((p) => p.dispose());
  return { x, y, z, speed: 0.5 + r(0.7), scale: 1.4 + r(1.8), geom };
}

export function Clouds() {
  const groupRef = useRef<THREE.Group>(null);
  const clouds = useMemo<CloudDef[]>(() => {
    const arr: CloudDef[] = [];
    for (let i = 0; i < 11; i++) {
      arr.push(
        makeCloud(
          i * 77 + 13,
          -100 + i * 19 + (i % 3) * 7,
          21 + (i % 4) * 3.2,
          -85 + ((i * 53) % 170)
        )
      );
    }
    return arr;
  }, []);
  const mat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#ffffff",
        roughness: 1,
        flatShading: true,
        transparent: true,
        opacity: 0.82,
        emissive: "#dfe9f5",
        emissiveIntensity: 0.25,
      }),
    []
  );
  useFrame((_, dt) => {
    const g = groupRef.current;
    if (!g) return;
    for (const child of g.children) {
      child.position.x += (child.userData.speed as number) * dt;
      if (child.position.x > 120) child.position.x = -120;
    }
  });
  return (
    <group ref={groupRef}>
      {clouds.map((c, i) => (
        <mesh
          key={i}
          geometry={c.geom}
          material={mat}
          position={[c.x, c.y, c.z]}
          scale={c.scale}
          userData={{ speed: c.speed }}
        />
      ))}
    </group>
  );
}
