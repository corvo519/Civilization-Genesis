import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Globe, Users, Flag, Building2, Swords, Pause, Play, FastForward, ChevronsRight,
  Volume2, VolumeX, RefreshCw, CircleHelp, Hourglass,
  Eye, Mountain, Waves, Droplets, TreePine, Gem, Crown, FlameKindling, Zap, X,
} from "lucide-react";
import { useStore } from "../../game/store";
import type { ToolId } from "../../game/types";
import { fmtYear, fmtNum } from "./format";
import { cn } from "../../utils/cn";

export const TOOLS: { id: ToolId; label: string; hint: string; icon: typeof Eye; key: string }[] = [
  { id: "observe", label: "Observar", hint: "Clique num território ou cidade para inspecionar o povo", icon: Eye, key: "1" },
  { id: "mountain", label: "Erguer Montanhas", hint: "Arraste para erguer cordilheiras e picos nevados", icon: Mountain, key: "2" },
  { id: "ocean", label: "Cavar Oceanos", hint: "Afunde a terra para criar lagos, mares e ilhas", icon: Waves, key: "3" },
  { id: "river", label: "Traçar Rio", hint: "Clique numa altitude e um rio descerá até o mar", icon: Droplets, key: "4" },
  { id: "forest", label: "Plantar Florestas", hint: "Pinte bosques densos que alimentam os povos", icon: TreePine, key: "5" },
  { id: "resource", label: "Gerar Recursos", hint: "Semeie ouro, ferro e gemas pelo solo", icon: Gem, key: "6" },
  { id: "bless", label: "Abençoar Povo", hint: "Clique num reino: crescimento e tecnologia divinos por 30 anos", icon: Crown, key: "7" },
  { id: "volcano", label: "Vulcão", hint: "Ferva a terra e crie um vulcão devastador", icon: FlameKindling, key: "8" },
  { id: "meteor", label: "Meteoro", hint: "Convoque um impacto celestial sobre o mundo", icon: Zap, key: "9" },
];

const BRUSH_TOOLS: ToolId[] = ["mountain", "ocean", "forest", "resource"];

export function TopBar() {
  const year = useStore((s) => s.year);
  const speed = useStore((s) => s.speed);
  const setSpeed = useStore((s) => s.setSpeed);
  const muted = useStore((s) => s.muted);
  const toggleMute = useStore((s) => s.toggleMute);
  const stats = useStore((s) => s.stats);
  const start = useStore((s) => s.start);
  const toggleHelp = useStore((s) => s.toggleHelp);

  const speedBtn =
    "flex h-8 w-8 items-center justify-center rounded-lg transition-all duration-150";

  return (
    <div className="pointer-events-none fixed left-1/2 top-3 z-40 w-[min(96vw,1080px)] -translate-x-1/2">
      <div className="glass pointer-events-auto flex items-center justify-between gap-3 rounded-2xl px-4 py-2.5">
        {/* brand */}
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-b from-[#d8b45a]/25 to-transparent border border-[#d8b45a]/40">
            <Globe size={15} style={{ color: "#f3dfa4" }} />
          </div>
          <div className="hidden sm:block">
            <div className="font-display text-[13px] font-bold leading-none tracking-[0.18em] text-slate-100">
              GENESIS <span className="gold-text">3D</span>
            </div>
            <div className="mt-1 text-[9px] uppercase tracking-[0.24em] text-slate-400">Simulador de Civilizações</div>
          </div>
        </div>

        {/* stats */}
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5" title="Ano corrente">
            <Hourglass size={13} style={{ color: "#d8b45a" }} />
            <span className="font-display text-[13px] font-bold text-slate-100 tabular-nums">{fmtYear(year)}</span>
          </div>
          <div className="hidden h-4 w-px bg-white/10 md:block" />
          <div className="hidden items-center gap-1.5 md:flex" title="População mundial">
            <Users size={13} className="text-slate-400" />
            <span className="tabular-nums text-slate-200">{fmtNum(stats.pop)}</span>
          </div>
          <div className="hidden items-center gap-1.5 sm:flex" title="Civilizações">
            <Flag size={13} className="text-slate-400" />
            <span className="tabular-nums text-slate-200">{stats.civs}</span>
          </div>
          <div className="hidden items-center gap-1.5 lg:flex" title="Cidades">
            <Building2 size={13} className="text-slate-400" />
            <span className="tabular-nums text-slate-200">{stats.cities}</span>
          </div>
          <div className={cn("hidden items-center gap-1.5 sm:flex", stats.wars > 0 && "animate-pulse-glow")} title="Guerras ativas">
            <Swords size={13} style={{ color: stats.wars > 0 ? "#ff7a6b" : "#94a3b8" }} />
            <span className="tabular-nums" style={{ color: stats.wars > 0 ? "#ffb0a5" : "#e2e8f0" }}>{stats.wars}</span>
          </div>
        </div>

        {/* controls */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setSpeed(speed === 0 ? 1 : 0)}
            className={cn(speedBtn, speed === 0 ? "bg-[#d8b45a]/25 text-[#f3dfa4]" : "text-slate-300 hover:bg-white/10")}
            title={speed === 0 ? "Retomar (Espaço)" : "Pausar (Espaço)"}
          >
            {speed === 0 ? <Play size={14} /> : <Pause size={14} />}
          </button>
          {[1, 2, 4].map((v, i) => (
            <button
              key={v}
              onClick={() => setSpeed(v)}
              className={cn(speedBtn, speed === v ? "bg-[#d8b45a]/25 text-[#f3dfa4]" : "text-slate-300 hover:bg-white/10")}
              title={`Velocidade ${v}x`}
            >
              {i === 0 ? <Play size={14} /> : i === 1 ? <FastForward size={14} /> : <ChevronsRight size={15} />}
            </button>
          ))}
          <div className="mx-1 h-4 w-px bg-white/10" />
          <button onClick={toggleMute} className={cn(speedBtn, "text-slate-300 hover:bg-white/10")} title="Som">
            {muted ? <VolumeX size={14} /> : <Volume2 size={14} />}
          </button>
          <button onClick={start} className={cn(speedBtn, "text-slate-300 hover:bg-white/10")} title="Gerar novo mundo">
            <RefreshCw size={14} />
          </button>
          <button onClick={toggleHelp} className={cn(speedBtn, "text-slate-300 hover:bg-white/10")} title="Ajuda (H)">
            <CircleHelp size={15} />
          </button>
        </div>
      </div>
    </div>
  );
}

export function Toolbar() {
  const tool = useStore((s) => s.tool);
  const setTool = useStore((s) => s.setTool);
  const brush = useStore((s) => s.brush);
  const setBrush = useStore((s) => s.setBrush);

  const active = TOOLS.find((t) => t.id === tool)!;

  return (
    <>
      <div className="fixed left-3 top-1/2 z-40 -translate-y-1/2">
        <div className="glass flex flex-col gap-1 rounded-2xl p-1.5">
          {TOOLS.map((t) => {
            const Icon = t.icon;
            const isActive = tool === t.id;
            return (
              <div key={t.id} className="group relative">
                <button
                  onClick={() => setTool(t.id)}
                  className={cn(
                    "flex h-10 w-10 items-center justify-center rounded-xl transition-all duration-150",
                    isActive
                      ? "bg-gradient-to-b from-[#d8b45a]/35 to-[#d8b45a]/10 text-[#f3dfa4] shadow-[0_0_18px_rgba(216,180,90,0.35)] border border-[#d8b45a]/50"
                      : "text-slate-300/80 hover:bg-white/10 hover:text-white border border-transparent"
                  )}
                >
                  <Icon size={17} />
                </button>
                <div className="pointer-events-none absolute left-full top-1/2 ml-2.5 hidden -translate-y-1/2 whitespace-nowrap rounded-lg border border-white/10 bg-[#0a0f1c]/95 px-2.5 py-1.5 text-[11px] font-medium text-slate-200 shadow-xl group-hover:block">
                  {t.label}
                  <span className="ml-2 rounded bg-white/10 px-1 py-0.5 text-[9px] text-slate-400">{t.key}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* brush + hint */}
      <AnimatePresence>
        <motion.div
          key={tool}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 6 }}
          className="pointer-events-none fixed bottom-4 left-1/2 z-40 -translate-x-1/2"
        >
          <div className="glass pointer-events-auto flex items-center gap-4 rounded-2xl px-5 py-2.5">
            <div className="flex items-center gap-2">
              <active.icon size={15} style={{ color: "#f3dfa4" }} />
              <span className="text-xs font-semibold text-slate-100">{active.label}</span>
            </div>
            <span className="hidden max-w-[300px] truncate text-[11px] text-slate-400 md:block">{active.hint}</span>
            {BRUSH_TOOLS.includes(tool) && (
              <div className="flex items-center gap-2">
                <span className="text-[9px] uppercase tracking-widest text-slate-500">Raio</span>
                <input
                  type="range"
                  min={2}
                  max={9}
                  step={1}
                  value={brush}
                  onChange={(e) => setBrush(Number(e.target.value))}
                  className="brush-range w-24"
                />
                <span className="w-4 text-center text-xs font-bold tabular-nums text-[#f3dfa4]">{brush}</span>
              </div>
            )}
          </div>
        </motion.div>
      </AnimatePresence>
    </>
  );
}

export function HelpOverlay() {
  const open = useStore((s) => s.helpOpen);
  const toggle = useStore((s) => s.toggleHelp);
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
          onClick={toggle}
        >
          <motion.div
            initial={{ scale: 0.92, y: 16 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.95, y: 8 }}
            transition={{ type: "spring", damping: 24, stiffness: 300 }}
            className="glass max-h-[85vh] w-[min(92vw,620px)] overflow-y-auto scroll-slim rounded-2xl p-7"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between">
              <div>
                <h2 className="font-display text-xl font-bold tracking-wide text-slate-100">
                  Guia do <span className="gold-text">Criador</span>
                </h2>
                <p className="mt-1 text-xs text-slate-400">Molde o mundo, observe as eras, decida os destinos.</p>
              </div>
              <button onClick={toggle} className="rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-white">
                <X size={16} />
              </button>
            </div>

            <div className="mt-5 grid grid-cols-1 gap-2 sm:grid-cols-2">
              {TOOLS.map((t) => (
                <div key={t.id} className="flex items-start gap-3 rounded-xl border border-white/5 bg-white/[0.03] p-3">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#d8b45a]/15 border border-[#d8b45a]/30">
                    <t.icon size={14} style={{ color: "#f3dfa4" }} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-100">
                      {t.label}
                      <span className="rounded bg-white/10 px-1 text-[9px] text-slate-400">{t.key}</span>
                    </div>
                    <div className="mt-0.5 text-[11px] leading-snug text-slate-400">{t.hint}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-5 rounded-xl border border-white/5 bg-white/[0.03] p-4">
              <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400">Controles de câmera</div>
              <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1.5 text-[11px] text-slate-300">
                <span>Botão direito — orbitar</span>
                <span>Scroll — zoom</span>
                <span>WASD / setas — mover</span>
                <span>Botão do meio — arrastar</span>
                <span>Espaço — pausar / retomar</span>
                <span>Teclas 1–9 — ferramentas</span>
              </div>
            </div>

            <p className="mt-4 text-center text-[10px] uppercase tracking-[0.3em] text-slate-500">
              Não há vitória fixa — a história é sua
            </p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* Onboarding hints shown right after world creation */
const HINTS = [
  { icon: Globe, text: "O mundo despertou. Cinco tribos nasceram — elas crescerão, fundarão cidades e farão história." },
  { icon: Mountain, text: "Use as ferramentas à esquerda (teclas 1–9) para moldar montanhas, rios e florestas." },
  { icon: Crown, text: "Clique num território com a ferramenta Observar para inspecionar um reino — ou pressione H para o guia completo." },
];

export function GameHints() {
  const [step, setStep] = useState(0);
  useEffect(() => {
    if (step >= HINTS.length) return;
    const t = setTimeout(() => setStep((s) => s + 1), step === 0 ? 6500 : 6000);
    return () => clearTimeout(t);
  }, [step]);

  const hint = HINTS[step] as (typeof HINTS)[number] | undefined;
  return (
    <div className="pointer-events-none fixed bottom-20 left-1/2 z-40 -translate-x-1/2">
      <AnimatePresence>
        {hint && (
          <motion.div
            key={step}
            initial={{ opacity: 0, y: 14, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.98 }}
            transition={{ duration: 0.4 }}
            className="glass flex max-w-md items-center gap-2.5 rounded-2xl px-4 py-2.5"
          >
            <hint.icon size={15} className="shrink-0" style={{ color: "#f3dfa4" }} />
            <span className="text-xs leading-snug text-slate-200">{hint.text}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
