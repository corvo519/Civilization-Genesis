import { motion, AnimatePresence } from "framer-motion";
import {
  Tent, Wheat, Castle, Factory, Rocket, Users, Swords, Building2, Landmark,
  ChevronLeft, Crown, MapPin, Handshake, Sparkles,
} from "lucide-react";
import { useStore } from "../../game/store";
import { ERAS } from "../../game/types";
import type { CivSnap } from "../../game/types";
import { fmtYear, fmtNum } from "./format";
import { cn } from "../../utils/cn";

export const ERA_ICONS = [Tent, Wheat, Castle, Factory, Rocket];

function EraChip({ era }: { era: number }) {
  const Icon = ERA_ICONS[era];
  const def = ERAS[era];
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold"
      style={{ background: `${def.color}22`, color: def.color, border: `1px solid ${def.color}44` }}
    >
      <Icon size={10} />
      {def.name}
    </span>
  );
}

function CivRow({ c, onSelect, selected }: { c: CivSnap; onSelect: () => void; selected: boolean }) {
  const Icon = ERA_ICONS[c.era];
  return (
    <button
      onClick={onSelect}
      className={cn(
        "flex w-full items-center gap-2.5 rounded-xl border px-3 py-2 text-left transition-all duration-150",
        selected
          ? "border-[#d8b45a]/50 bg-[#d8b45a]/10"
          : "border-transparent hover:border-white/10 hover:bg-white/5"
      )}
    >
      <span
        className="h-7 w-2 shrink-0 rounded-full"
        style={{ background: c.color, boxShadow: `0 0 10px ${c.color}88` }}
      />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <span className="truncate text-xs font-bold text-slate-100">{c.name}</span>
          {c.blessed > 0 && <Crown size={10} style={{ color: "#ffd76b" }} />}
          {c.wars > 0 && <Swords size={10} className="text-red-400" />}
        </div>
        <div className="mt-0.5 flex items-center gap-2 text-[10px] text-slate-400">
          <span className="flex items-center gap-1" style={{ color: ERAS[c.era].color }}>
            <Icon size={9} />
            {ERAS[c.era].name.replace("Era ", "")}
          </span>
          <span className="flex items-center gap-1 tabular-nums">
            <Users size={9} /> {fmtNum(c.pop)}
          </span>
        </div>
      </div>
      <span className="text-[10px] tabular-nums text-slate-500">{c.territorySize}⬡</span>
    </button>
  );
}

function CivDetail({ c }: { c: CivSnap }) {
  const selectCiv = useStore((s) => s.selectCiv);
  const blessCiv = useStore((s) => s.blessCiv);
  const eraDef = ERAS[c.era];
  const techPct = c.era >= 4 ? 100 : Math.min(100, (c.tech / eraDef.techNeed) * 100);

  const stat = (Icon: typeof Users, label: string, value: string) => (
    <div className="rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2">
      <div className="flex items-center gap-1.5 text-[9px] uppercase tracking-[0.15em] text-slate-500">
        <Icon size={10} />
        {label}
      </div>
      <div className="mt-1 text-sm font-bold tabular-nums text-slate-100">{value}</div>
    </div>
  );

  return (
    <motion.div
      key={c.id}
      initial={{ opacity: 0, x: 14 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 14 }}
      transition={{ duration: 0.22 }}
    >
      <button
        onClick={() => selectCiv(null)}
        className="mb-3 flex items-center gap-1 text-[11px] font-medium text-slate-400 hover:text-white"
      >
        <ChevronLeft size={13} /> Todas as civilizações
      </button>

      <div className="flex items-center gap-2.5">
        <span className="h-9 w-2.5 rounded-full" style={{ background: c.color, boxShadow: `0 0 14px ${c.color}` }} />
        <div className="min-w-0">
          <div className="truncate font-display text-base font-bold text-slate-50">{c.name}</div>
          <div className="text-[10px] text-slate-400">Fundada em {fmtYear(c.founded)}</div>
        </div>
      </div>

      <div className="mt-3">
        <EraChip era={c.era} />
        {c.blessed > 0 && (
          <span className="ml-1.5 inline-flex items-center gap-1 rounded-full border border-[#ffd76b]/50 bg-[#ffd76b]/15 px-2 py-0.5 text-[10px] font-semibold text-[#ffd76b]">
            <Sparkles size={9} /> Abençoada · {c.blessed} anos
          </span>
        )}
      </div>

      {/* tech progress */}
      <div className="mt-3">
        <div className="flex justify-between text-[9px] uppercase tracking-widest text-slate-500">
          <span>Pesquisa</span>
          <span>{c.era >= 4 ? "Era máxima" : `${Math.round(techPct)}%`}</span>
        </div>
        <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/8">
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{ width: `${techPct}%`, background: `linear-gradient(90deg, ${eraDef.color}, #f3dfa4)` }}
          />
        </div>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2">
        {stat(Users, "População", fmtNum(c.pop))}
        {stat(Swords, "Exército", fmtNum(c.military))}
        {stat(Landmark, "Território", `${c.territorySize} terras`)}
        {stat(Building2, "Cidades", `${c.citiesCount}`)}
      </div>

      {(c.enemies.length > 0 || c.allies.length > 0) && (
        <div className="mt-3 space-y-1.5">
          {c.enemies.map((e) => (
            <div key={e.id} className="flex items-center gap-2 rounded-lg border border-red-500/20 bg-red-500/10 px-2.5 py-1.5 text-[11px] text-red-200">
              <Swords size={11} className="text-red-400" />
              Em guerra com <span className="font-bold">{e.name}</span>
            </div>
          ))}
          {c.allies.map((a) => (
            <div key={a.id} className="flex items-center gap-2 rounded-lg border border-emerald-500/20 bg-emerald-500/10 px-2.5 py-1.5 text-[11px] text-emerald-200">
              <Handshake size={11} className="text-emerald-400" />
              Aliada de <span className="font-bold">{a.name}</span>
            </div>
          ))}
        </div>
      )}

      <div className="mt-4 flex gap-2">
        <button
          onClick={() => selectCiv(c.id, true)}
          className="flex flex-1 items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-[11px] font-semibold text-slate-200 transition hover:bg-white/10"
        >
          <MapPin size={12} /> Localizar
        </button>
        <button
          onClick={() => blessCiv(c.id)}
          disabled={c.blessed > 0}
          className={cn(
            "flex flex-1 items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-[11px] font-bold transition",
            c.blessed > 0
              ? "cursor-not-allowed border border-[#ffd76b]/30 bg-[#ffd76b]/10 text-[#ffd76b]/60"
              : "border border-[#d8b45a]/60 bg-gradient-to-b from-[#d8b45a]/30 to-[#d8b45a]/10 text-[#f3dfa4] hover:shadow-[0_0_20px_rgba(216,180,90,0.35)]"
          )}
        >
          <Crown size={12} /> Abençoar
        </button>
      </div>
    </motion.div>
  );
}

export function CivPanel() {
  const civs = useStore((s) => s.civs);
  const selectedCiv = useStore((s) => s.selectedCiv);
  const selectCiv = useStore((s) => s.selectCiv);

  const selected = civs.find((c) => c.id === selectedCiv);

  return (
    <div className="fixed right-3 top-[66px] z-40 w-[280px] max-w-[calc(100vw-24px)]">
      <div className="glass max-h-[calc(100vh-210px)] overflow-y-auto scroll-slim rounded-2xl p-3.5">
        <AnimatePresence mode="wait">
          {selected ? (
            <CivDetail key="detail" c={selected} />
          ) : (
            <motion.div
              key="list"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
            >
              <div className="mb-2 flex items-center justify-between px-1">
                <span className="text-[10px] font-bold uppercase tracking-[0.22em] text-slate-400">
                  Civilizações
                </span>
                <span className="rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-bold text-slate-200">
                  {civs.length}
                </span>
              </div>
              <div className="flex flex-col gap-1">
                {civs.map((c) => (
                  <CivRow key={c.id} c={c} selected={false} onSelect={() => selectCiv(c.id, true)} />
                ))}
                {civs.length === 0 && (
                  <div className="px-2 py-6 text-center text-[11px] italic text-slate-500">
                    Todas as civilizações caíram. <br /> O mundo aguarda um novo ciclo.
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
