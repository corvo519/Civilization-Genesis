import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles, Flag, ChevronsRight, Swords, Shield, Handshake, Skull, Flame, Crown, ScrollText,
} from "lucide-react";
import { useStore } from "../../game/store";
import type { EventKind } from "../../game/types";
import { fmtYear } from "./format";

const KIND_STYLE: Record<EventKind, { icon: typeof Flag; color: string; bg: string }> = {
  genesis: { icon: Sparkles, color: "#f3dfa4", bg: "rgba(216,180,90,0.14)" },
  found: { icon: Flag, color: "#6ee7b7", bg: "rgba(52,211,153,0.12)" },
  era: { icon: ChevronsRight, color: "#93c5fd", bg: "rgba(96,165,250,0.12)" },
  war: { icon: Swords, color: "#fca5a5", bg: "rgba(239,68,68,0.14)" },
  peace: { icon: Shield, color: "#7dd3fc", bg: "rgba(56,189,248,0.12)" },
  ally: { icon: Handshake, color: "#86efac", bg: "rgba(74,222,128,0.12)" },
  fall: { icon: Skull, color: "#fda4af", bg: "rgba(244,63,94,0.14)" },
  disaster: { icon: Flame, color: "#fdba74", bg: "rgba(249,115,22,0.14)" },
  bless: { icon: Crown, color: "#fde68a", bg: "rgba(251,191,36,0.14)" },
  conquer: { icon: Swords, color: "#fcd34d", bg: "rgba(245,158,11,0.14)" },
};

export function EventLog() {
  const events = useStore((s) => s.events);
  const shown = events.slice(0, 7);

  return (
    <div className="pointer-events-none fixed bottom-4 left-16 z-30 w-[300px] max-w-[42vw]">
      <div className="mb-1.5 flex items-center gap-1.5 px-1">
        <ScrollText size={11} style={{ color: "#d8b45a" }} />
        <span className="text-[9px] font-bold uppercase tracking-[0.24em] text-slate-400">
          Crônicas do Mundo
        </span>
      </div>
      <div className="flex flex-col-reverse gap-1">
        <AnimatePresence initial={false}>
          {shown.map((e, idx) => {
            const st = KIND_STYLE[e.kind];
            const Icon = st.icon;
            return (
              <motion.div
                key={e.id}
                layout
                initial={{ opacity: 0, x: -18, scale: 0.96 }}
                animate={{ opacity: Math.max(0.28, 1 - idx * 0.13), x: 0, scale: 1 }}
                exit={{ opacity: 0, x: -12 }}
                transition={{ duration: 0.28 }}
                className="glass-soft flex items-start gap-2 rounded-xl px-2.5 py-1.5"
                style={{ borderLeft: `2px solid ${st.color}` }}
              >
                <span
                  className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md"
                  style={{ background: st.bg }}
                >
                  <Icon size={11} style={{ color: st.color }} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-[11px] leading-snug text-slate-200">{e.text}</p>
                  <p className="mt-0.5 text-[9px] tabular-nums text-slate-500">{fmtYear(e.year)}</p>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
}
