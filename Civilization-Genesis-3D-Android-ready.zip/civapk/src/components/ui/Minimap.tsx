import { useCallback, useEffect, useRef } from "react";
import { useStore, getG } from "../../game/store";
import { W, H, SEA, CAT_WATER, CAT_SAND, CAT_GRASS, CAT_FOREST, CAT_ROCK, CAT_SNOW } from "../../game/types";

const hexCache = new Map<string, [number, number, number]>();
function hexRgb(hex: string): [number, number, number] {
  let c = hexCache.get(hex);
  if (!c) {
    c = [parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16), parseInt(hex.slice(5, 7), 16)];
    hexCache.set(hex, c);
  }
  return c;
}

export function Minimap() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const minimapTick = useStore((s) => s.minimapTick);
  const terrainVer = useStore((s) => s.versions.terrain);
  const focusAt = useStore((s) => s.focusAt);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const G = getG();
    if (!canvas || !G) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const img = ctx.createImageData(W, H);
    const d = img.data;
    const w = G.world;
    const civColors = new Map<number, [number, number, number]>();
    for (const c of G.civs) if (c.alive) civColors.set(c.id, hexRgb(c.color));

    for (let i = 0; i < W * H; i++) {
      const o = i * 4;
      const cat = w.cat[i];
      let r = 0, g = 0, b = 0;
      if (cat === CAT_WATER) {
        const depth = Math.min(1, (SEA - w.height[i]) / 0.22);
        r = 16 + (1 - depth) * 30; g = 62 + (1 - depth) * 42; b = 106 + (1 - depth) * 34;
      } else if (cat === CAT_SAND) { r = 205; g = 183; b = 128; }
      else if (cat === CAT_GRASS) { r = 96; g = 143; b = 74; }
      else if (cat === CAT_FOREST) { r = 56; g = 110; b = 60; }
      else if (cat === CAT_ROCK) { r = 122; g = 128; b = 138; }
      else if (cat === CAT_SNOW) { r = 228; g = 236; b = 245; }

      if (w.river[i] && cat !== CAT_WATER) { r = 70; g = 150; b = 205; }
      if (w.scorch[i] > 0.05 && cat !== CAT_WATER) {
        const s = Math.min(1, w.scorch[i]);
        r = r * (1 - s) + 40 * s; g = g * (1 - s) + 32 * s; b = b * (1 - s) + 26 * s;
      }

      const owner = w.owner[i];
      if (owner >= 0) {
        const cc = civColors.get(owner);
        if (cc) {
          const t = 0.55;
          r = r * (1 - t) + cc[0] * t;
          g = g * (1 - t) + cc[1] * t;
          b = b * (1 - t) + cc[2] * t;
        }
      }

      d[o] = r; d[o + 1] = g; d[o + 2] = b; d[o + 3] = 255;
    }

    // cities as bright markers
    for (const c of G.cities) {
      const x = c.tile % W, y = Math.floor(c.tile / W);
      const put = (px: number, py: number, big: boolean) => {
        const rad = big ? 2 : 1;
        for (let dy = -rad; dy <= rad; dy++)
          for (let dx = -rad; dx <= rad; dx++) {
            const xx = px + dx, yy = py + dy;
            if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue;
            const o = (yy * W + xx) * 4;
            d[o] = 255; d[o + 1] = 244; d[o + 2] = 214; d[o + 3] = 255;
          }
      };
      put(x, y, c.capital);
    }

    ctx.putImageData(img, 0, 0);
  }, []);

  useEffect(() => { draw(); }, [draw, minimapTick, terrainVer]);
  useEffect(() => {
    const t = setInterval(draw, 1500);
    return () => clearInterval(t);
  }, [draw]);

  return (
    <div className="fixed bottom-4 right-3 z-40">
      <div className="glass overflow-hidden rounded-xl p-1.5">
        <canvas
          ref={canvasRef}
          width={W}
          height={H}
          className="block h-[156px] w-[156px] cursor-pointer rounded-lg"
          style={{ imageRendering: "pixelated" }}
          onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const px = ((e.clientX - rect.left) / rect.width) * W;
            const py = ((e.clientY - rect.top) / rect.height) * H;
            focusAt(Math.floor(px) - W / 2 + 0.5, Math.floor(py) - H / 2 + 0.5);
          }}
          title="Mapa-múndi — clique para viajar"
        />
      </div>
      <div className="mt-1 text-center text-[8px] uppercase tracking-[0.3em] text-slate-500">Mapa-Múndi</div>
    </div>
  );
}
