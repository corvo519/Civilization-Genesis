import { useState } from "react";
import { motion } from "framer-motion";
import {
  Globe, Swords, Sparkles, LoaderCircle, Mountain, Crown, Telescope, Orbit,
} from "lucide-react";
import { useStore } from "../../game/store";

const FEATURES = [
  { icon: Sparkles, title: "5 Eras", desc: "Da tribo primitiva à era tecnológica" },
  { icon: Swords, title: "Guerras & Alianças", desc: "Reinos expandem, lutam e caem" },
  { icon: Mountain, title: "Poderes Divinos", desc: "Montanhas, rios, vulcões e meteoros" },
  { icon: Telescope, title: "Mundo Vivo", desc: "Observe séculos de evolução emergente" },
];

export function TitleScreen() {
  const start = useStore((s) => s.start);
  const [generating, setGenerating] = useState(false);

  const launch = () => {
    if (generating) return;
    setGenerating(true);
    setTimeout(() => start(), 550);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-[#060b16]">
      {/* backdrop art */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-60"
        style={{ backgroundImage: "url(images/title-bg.jpg)" }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#060b16]/70 via-[#060b16]/35 to-[#060b16]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(6,11,22,0.75)_78%)]" />

      <div className="relative flex h-full flex-col items-center justify-center px-6">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col items-center"
        >
          <motion.div
            initial={{ opacity: 0, letterSpacing: "0.2em" }}
            animate={{ opacity: 1, letterSpacing: "0.5em" }}
            transition={{ duration: 1.4, delay: 0.2 }}
            className="mb-5 flex items-center gap-3 text-[11px] font-medium uppercase text-sky-200/70"
          >
            <Orbit size={14} className="text-gold" style={{ color: "#d8b45a" }} />
            <span>Simulador de Deus · Estratégia · Mundo Aberto</span>
            <Orbit size={14} style={{ color: "#d8b45a" }} />
          </motion.div>

          <h1 className="text-center font-display text-[13vw] font-black leading-[0.95] tracking-tight sm:text-7xl md:text-8xl">
            <span className="title-shimmer block">CIVILIZATION</span>
            <span className="mt-1 block text-slate-100">
              GENESIS <span className="gold-text">3D</span>
            </span>
          </h1>

          <div className="mt-6 h-px w-72 bg-gradient-to-r from-transparent via-[#d8b45a]/70 to-transparent" />

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7, duration: 1 }}
            className="mt-5 max-w-xl text-center text-sm leading-relaxed text-slate-300/85 sm:text-base"
          >
            Molde um planeta do zero. Povos surgem, aldeias tornam-se impérios,
            alianças se formam e guerras reescrevem o mapa — enquanto você decide
            entre criar paraísos ou cataclismos.
          </motion.p>

          <motion.button
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.7 }}
            onClick={launch}
            disabled={generating}
            className="group relative mt-9 flex items-center gap-3 overflow-hidden rounded-full border border-[#d8b45a]/50 bg-gradient-to-b from-[#2a2410]/80 to-[#161204]/80 px-10 py-4 font-display text-sm font-bold tracking-[0.25em] text-[#f3dfa4] transition-all duration-300 hover:border-[#f3dfa4] hover:shadow-[0_0_50px_rgba(216,180,90,0.35)] disabled:opacity-80"
          >
            <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-[#f3dfa4]/15 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
            {generating ? (
              <>
                <LoaderCircle size={18} className="animate-spin" />
                GERANDO MUNDO...
              </>
            ) : (
              <>
                <Globe size={18} />
                CRIAR O MUNDO
              </>
            )}
          </motion.button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.25, duration: 0.8 }}
          className="absolute bottom-8 grid w-full max-w-4xl grid-cols-2 gap-3 px-6 md:grid-cols-4"
        >
          {FEATURES.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.35 + i * 0.12, duration: 0.6 }}
              className="glass-soft rounded-xl px-4 py-3"
            >
              <f.icon size={16} style={{ color: "#d8b45a" }} />
              <div className="mt-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-100">
                {f.title}
              </div>
              <div className="mt-1 text-[11px] leading-snug text-slate-400">{f.desc}</div>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
          className="absolute bottom-2 flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-slate-500"
        >
          <Crown size={10} style={{ color: "#d8b45a" }} />
          A história do seu mundo começa com um clique
        </motion.div>
      </div>
    </div>
  );
}
