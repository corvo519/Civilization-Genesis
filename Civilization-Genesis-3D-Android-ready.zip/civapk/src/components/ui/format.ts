export function fmtYear(y: number): string {
  const v = Math.floor(y);
  return v < 0 ? `${-v} a.C.` : `${v} d.C.`;
}

const compact = new Intl.NumberFormat("pt-BR", { notation: "compact", maximumFractionDigits: 1 });
export const fmtNum = (n: number) => compact.format(n);
