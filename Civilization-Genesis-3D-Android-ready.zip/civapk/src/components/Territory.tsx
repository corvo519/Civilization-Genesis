import { useEffect, useMemo } from "react";
import * as THREE from "three";
import { useStore, getG } from "../game/store";
import { W, H, idx, HG } from "../game/types";

function buildTerritoryGeometry(): THREE.BufferGeometry | null {
  const G = getG();
  if (!G) return null;
  const w = G.world;

  // count owned quads
  let count = 0;
  for (let z = 0; z < H - 1; z++)
    for (let x = 0; x < W - 1; x++) if (w.owner[idx(x, z)] >= 0) count++;
  if (count === 0) return null;

  const pos = new Float32Array(count * 6 * 3);
  const col = new Float32Array(count * 6 * 3);
  const civColor = new Map<number, THREE.Color>();
  for (const c of G.civs) if (c.alive) civColor.set(c.id, new THREE.Color(c.color));

  const tmp = new THREE.Color();
  const vh = (x: number, z: number) => w.height[idx(Math.min(x, W - 1), Math.min(z, H - 1))] * HG + 0.13;

  // is grid vertex at border between different owners?
  const borderAt = (vx: number, vz: number, owner: number) => {
    for (const [dx, dz] of [[0, 0], [-1, 0], [0, -1], [-1, -1]] as const) {
      const tx = vx + dx, tz = vz + dz;
      if (tx < 0 || tz < 0 || tx >= W || tz >= H) continue;
      if (w.owner[idx(tx, tz)] !== owner) return true;
    }
    return false;
  };

  let p = 0;
  const pushV = (x: number, z: number, owner: number, cornerOwner: number) => {
    pos[p] = x - W / 2; pos[p + 1] = vh(x, z); pos[p + 2] = z - H / 2;
    tmp.copy(civColor.get(owner)!);
    if (borderAt(x, z, cornerOwner)) tmp.multiplyScalar(0.42);
    col[p] = tmp.r; col[p + 1] = tmp.g; col[p + 2] = tmp.b;
    p += 3;
  };

  for (let z = 0; z < H - 1; z++) {
    for (let x = 0; x < W - 1; x++) {
      const owner = w.owner[idx(x, z)];
      if (owner < 0 || !civColor.has(owner)) continue;
      pushV(x, z, owner, owner);
      pushV(x, z + 1, owner, owner);
      pushV(x + 1, z + 1, owner, owner);
      pushV(x, z, owner, owner);
      pushV(x + 1, z + 1, owner, owner);
      pushV(x + 1, z, owner, owner);
    }
  }

  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  g.setAttribute("color", new THREE.BufferAttribute(col, 3));
  return g;
}

export function Territory() {
  const ver = useStore((s) => s.versions.territory);
  const geom = useMemo(() => buildTerritoryGeometry(), [ver]);
  useEffect(() => () => { geom?.dispose(); }, [geom]);
  if (!geom) return null;
  return (
    <mesh geometry={geom} renderOrder={3}>
      <meshBasicMaterial
        vertexColors
        transparent
        opacity={0.42}
        depthWrite={false}
        polygonOffset
        polygonOffsetFactor={-2}
        polygonOffsetUnits={-2}
      />
    </mesh>
  );
}
