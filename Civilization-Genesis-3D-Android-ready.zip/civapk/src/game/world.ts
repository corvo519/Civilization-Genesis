import { createNoise2D } from "simplex-noise";
import { mulberry32 } from "./rng";
import {
  W, H, N, SEA, idx, inB,
  CAT_WATER, CAT_SAND, CAT_GRASS, CAT_FOREST, CAT_ROCK, CAT_SNOW,
  RES_GOLD, RES_IRON, RES_GEM,
  type World,
} from "./types";

const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
const smooth = (a: number, b: number, x: number) => {
  const t = clamp01((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};

function fbm(noise: (x: number, y: number) => number, x: number, y: number, oct: number) {
  let v = 0, amp = 0.5, f = 1, tot = 0;
  for (let i = 0; i < oct; i++) {
    v += noise(x * f, y * f) * amp;
    tot += amp;
    amp *= 0.5;
    f *= 2.02;
  }
  return v / tot;
}

/* ------------------------------------------------ Classification */
export function classifyTile(w: World, i: number) {
  const h = w.height[i];
  if (h < SEA) { w.cat[i] = CAT_WATER; w.forest[i] = 0; w.river[i] = 0; return; }
  if (h > 0.83) { w.cat[i] = CAT_SNOW; w.forest[i] = 0; return; }
  if (h > 0.66) { w.cat[i] = CAT_ROCK; w.forest[i] = 0; return; }
  if (w.forest[i] && w.moist[i] > 0.34) { w.cat[i] = CAT_FOREST; return; }
  if (w.moist[i] < 0.26) { w.cat[i] = CAT_SAND; return; }
  w.cat[i] = CAT_GRASS;
}

export function classifyAll(w: World) {
  for (let i = 0; i < N; i++) classifyTile(w, i);
}

/* ------------------------------------------------ World generation */
export function generateWorld(seed: number): World {
  const rng = mulberry32(seed);
  const nElev = createNoise2D(mulberry32(seed ^ 0x9e3779b9));
  const nRidge = createNoise2D(mulberry32(seed ^ 0x3c6ef372));
  const nMoist = createNoise2D(mulberry32(seed ^ 0x1b873593));
  const nMount = createNoise2D(mulberry32(seed ^ 0x7f4a7c15));

  const w: World = {
    seed,
    height: new Float32Array(N),
    moist: new Float32Array(N),
    forest: new Uint8Array(N),
    river: new Uint8Array(N),
    res: new Uint8Array(N),
    owner: new Int16Array(N).fill(-1),
    city: new Int16Array(N).fill(-1),
    scorch: new Float32Array(N),
    cat: new Uint8Array(N),
    volcanoes: [],
  };

  const cx = W / 2, cz = H / 2;
  for (let z = 0; z < H; z++) {
    for (let x = 0; x < W; x++) {
      const i = idx(x, z);
      const e = fbm(nElev, x * 0.045, z * 0.045, 4);
      const base = e * 0.5 + 0.5;
      const ridge = 1 - Math.abs(fbm(nRidge, x * 0.055, z * 0.055, 3));
      const mMask = smooth(0.52, 0.78, fbm(nMount, x * 0.035, z * 0.035, 2) * 0.5 + 0.5);
      const d = Math.hypot(x - cx, z - cz) / (W * 0.5);
      const continental = 1.12 - smooth(0.5, 1.06, d) * 1.3;
      let h = base * 0.8 + ridge * mMask * 0.44;
      h = h * continental - 0.004;
      w.height[i] = clamp01(h);
      w.moist[i] = clamp01(fbm(nMoist, x * 0.07 + 31, z * 0.07 - 17, 3) * 0.5 + 0.5);
    }
  }

  // forests
  for (let i = 0; i < N; i++) {
    const h = w.height[i];
    if (h > SEA + 0.01 && h < 0.66 && w.moist[i] > 0.4 && rng() < (w.moist[i] - 0.38) * 2.1)
      w.forest[i] = 1;
  }

  // rivers from highlands
  let attempts = 0;
  let rivers = 0;
  while (rivers < 13 && attempts++ < 400) {
    const x = 2 + Math.floor(rng() * (W - 4));
    const z = 2 + Math.floor(rng() * (H - 4));
    const i = idx(x, z);
    if (w.height[i] > 0.5 && traceRiver(w, x, z)) rivers++;
  }

  // resources
  for (let z = 2; z < H - 2; z++) {
    for (let x = 2; x < W - 2; x++) {
      const i = idx(x, z);
      if (w.height[i] < SEA + 0.005) continue;
      const r = rng();
      if (w.height[i] > 0.6 && r < 0.05) w.res[i] = RES_IRON;
      else if (r < 0.014) w.res[i] = rng() < 0.5 ? RES_GOLD : RES_GEM;
    }
  }

  classifyAll(w);
  return w;
}

/* ------------------------------------------------ Terraform ops */
export function heightBlob(w: World, cx: number, cz: number, radius: number, amount: number) {
  const r2 = radius * radius;
  const x0 = Math.max(1, Math.floor(cx - radius)), x1 = Math.min(W - 3, Math.ceil(cx + radius));
  const z0 = Math.max(1, Math.floor(cz - radius)), z1 = Math.min(H - 3, Math.ceil(cz + radius));
  for (let z = z0; z <= z1; z++) {
    for (let x = x0; x <= x1; x++) {
      const dx = x - cx, dz = z - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 > r2) continue;
      const f = 1 - Math.sqrt(d2) / radius;
      const i = idx(x, z);
      w.height[i] = clamp01(w.height[i] + amount * f);
      classifyTile(w, i);
    }
  }
}

export function plantForest(w: World, cx: number, cz: number, radius: number, rngF: () => number) {
  const r2 = radius * radius;
  const x0 = Math.max(1, Math.floor(cx - radius)), x1 = Math.min(W - 3, Math.ceil(cx + radius));
  const z0 = Math.max(1, Math.floor(cz - radius)), z1 = Math.min(H - 3, Math.ceil(cz + radius));
  for (let z = z0; z <= z1; z++)
    for (let x = x0; x <= x1; x++) {
      const dx = x - cx, dz = z - cz;
      if (dx * dx + dz * dz > r2) continue;
      const i = idx(x, z);
      const h = w.height[i];
      if (h > SEA + 0.01 && h < 0.66 && rngF() < 0.85) w.forest[i] = 1;
      classifyTile(w, i);
    }
}

export function placeResources(w: World, cx: number, cz: number, radius: number, rngF: () => number) {
  const r2 = radius * radius;
  const x0 = Math.max(1, Math.floor(cx - radius)), x1 = Math.min(W - 3, Math.ceil(cx + radius));
  const z0 = Math.max(1, Math.floor(cz - radius)), z1 = Math.min(H - 3, Math.ceil(cz + radius));
  for (let z = z0; z <= z1; z++)
    for (let x = x0; x <= x1; x++) {
      const dx = x - cx, dz = z - cz;
      if (dx * dx + dz * dz > r2 || rngF() > 0.4) continue;
      const i = idx(x, z);
      if (w.height[i] < SEA + 0.005) continue;
      w.res[i] = (1 + Math.floor(rngF() * 3)) as typeof RES_GOLD | typeof RES_IRON | typeof RES_GEM;
    }
}

export function traceRiver(w: World, sx: number, sz: number): boolean {
  if (w.height[idx(sx, sz)] < SEA + 0.02) return false;
  const visited = new Set<number>();
  let x = sx, z = sz, steps = 0;
  while (steps++ < 300) {
    const i = idx(x, z);
    if (w.height[i] < SEA + 0.004) return steps > 3;
    if (visited.has(i)) return false;
    visited.add(i);
    w.river[i] = 1;
    // find lowest neighbor
    let bx = -1, bz = -1, bh = Infinity;
    const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]] as const;
    for (const [dx, dz] of dirs) {
      const nx = x + dx, nz = z + dz;
      if (!inB(nx, nz)) continue;
      const nh = w.height[idx(nx, nz)];
      if (nh < bh) { bh = nh; bx = nx; bz = nz; }
    }
    if (bx < 0) return false;
    if (bh >= w.height[i]) w.height[idx(bx, bz)] = Math.max(0.02, w.height[i] - 0.006);
    x = bx; z = bz;
  }
  return false;
}

export function volcanoRaise(w: World, cx: number, cz: number, radius: number) {
  const r2 = radius * radius;
  for (let z = Math.floor(cz - radius); z <= cz + radius; z++)
    for (let x = Math.floor(cx - radius); x <= cx + radius; x++) {
      if (!inB(x, z)) continue;
      const dx = x - cx, dz = z - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 > r2) continue;
      const f = Math.pow(1 - Math.sqrt(d2) / radius, 1.5);
      const i = idx(x, z);
      w.height[i] = clamp01(w.height[i] + f * 0.62);
      w.forest[i] = 0;
      w.river[i] = 0;
      scorchTile(w, i, Math.max(w.scorch[i], 0.4 + f * 0.6));
      classifyTile(w, i);
    }
  w.volcanoes.push({ tile: idx(Math.round(cx), Math.round(cz)), born: 0 });
}

export function craterCarve(w: World, cx: number, cz: number, radius: number) {
  const r2 = radius * radius;
  for (let z = Math.floor(cz - radius); z <= cz + radius; z++)
    for (let x = Math.floor(cx - radius); x <= cx + radius; x++) {
      if (!inB(x, z)) continue;
      const dx = x - cx, dz = z - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 > r2) continue;
      const f = 1 - Math.sqrt(d2) / radius;
      const i = idx(x, z);
      w.height[i] = clamp01(w.height[i] - f * 0.4);
      w.forest[i] = 0;
      scorchTile(w, i, Math.max(w.scorch[i], 0.5 + f * 0.5));
      classifyTile(w, i);
    }
}

export function scorchTile(w: World, i: number, v: number) {
  w.scorch[i] = Math.min(1, v);
}

export function scorchArea(w: World, cx: number, cz: number, radius: number, amt: number) {
  const r2 = radius * radius;
  for (let z = Math.floor(cz - radius); z <= cz + radius; z++)
    for (let x = Math.floor(cx - radius); x <= cx + radius; x++) {
      if (!inB(x, z)) continue;
      const dx = x - cx, dz = z - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 > r2) continue;
      const i = idx(x, z);
      scorchTile(w, i, Math.max(w.scorch[i], amt * (1 - Math.sqrt(d2) / radius)));
      w.forest[i] = 0;
      classifyTile(w, i);
    }
}

/* returns true if any tile decayed (terrain color needs rebuild) */
export function decayScorch(w: World, dtYears: number): boolean {
  let changed = false;
  for (let i = 0; i < N; i++) {
    if (w.scorch[i] > 0) {
      w.scorch[i] = Math.max(0, w.scorch[i] - dtYears * 0.028);
      changed = true;
    }
  }
  return changed;
}

/* ------------------------------------------------ Colors */
const C = (hex: number): [number, number, number] => [
  ((hex >> 16) & 255) / 255,
  ((hex >> 8) & 255) / 255,
  (hex & 255) / 255,
];
const COL = {
  deepWater: C(0x10344e),
  shallowWater: C(0x2f7d80),
  sand: C(0xdcc78f),
  grass: C(0x64a355),
  grassDry: C(0xa9b465),
  forest: C(0x3f7d44),
  rock: C(0x878e9b),
  snow: C(0xeef4fb),
  river: C(0x4aa8d8),
  scorch: C(0x2b241f),
};

function mix3(a: [number, number, number], b: [number, number, number], t: number): [number, number, number] {
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
}

export function tileColor(w: World, i: number, x: number, z: number): [number, number, number] {
  const cat = w.cat[i];
  let c: [number, number, number];
  if (cat === CAT_WATER) {
    const depth = Math.min(1, (SEA - w.height[i]) / 0.2);
    c = mix3(COL.shallowWater, COL.deepWater, depth);
  } else if (cat === CAT_SAND) c = COL.sand;
  else if (cat === CAT_ROCK) c = COL.rock;
  else if (cat === CAT_SNOW) c = COL.snow;
  else if (cat === CAT_FOREST) c = COL.forest;
  else c = w.moist[i] < 0.42 ? COL.grassDry : COL.grass;

  // subtle organic variation
  const v = (Math.sin(i * 12.9898) * 43758.5453) % 1;
  const jitter = 0.94 + Math.abs(v) * 0.12;
  c = [c[0] * jitter, c[1] * jitter, c[2] * jitter];

  if (w.river[i]) c = mix3(c, COL.river, 0.85);
  if (w.scorch[i] > 0.02 && cat !== CAT_WATER) c = mix3(c, COL.scorch, Math.min(1, w.scorch[i]));
  // beach sand near waterline
  if (cat === CAT_GRASS && w.height[i] < SEA + 0.015) c = mix3(c, COL.sand, 0.65);
  void x; void z;
  return c;
}
