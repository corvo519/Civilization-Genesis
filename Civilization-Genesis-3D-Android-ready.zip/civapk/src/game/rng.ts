// Deterministic RNG + fantasy name generators (PT-BR flavored)

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const rPick = <T>(r: () => number, arr: readonly T[]): T =>
  arr[Math.min(arr.length - 1, Math.floor(r() * arr.length))];

const CIV_A = ["Ael", "Thar", "Ka", "Bel", "Nor", "Zur", "Vel", "Dra", "Mir", "Os", "Tal", "Gar", "El", "Quen", "Az", "Il"];
const CIV_B = ["ion", "gard", "thia", "mer", "um", "ara", "or", "os", "wyn", "esh", "heim", "dor", "isia", "rok", "mir", "thas"];
const CIV_C = ["", "", "", "", "dor", "lia", "mar", "nia", "polis", "gard"];

export const genCivName = (r: () => number) =>
  rPick(r, CIV_A) + rPick(r, CIV_B) + rPick(r, CIV_C);

const CITY_A = ["Al", "Bel", "Cor", "Dun", "Er", "Fal", "Gal", "Har", "Ith", "Kar", "Lor", "Men", "Nar", "Ost", "Per", "Quel", "Rav", "Sel", "Tor", "Ul", "Var", "Yl"];
const CITY_B = ["a", "e", "i", "o", "u", "ia", "an", "en", "or", "ir"];
const CITY_C = ["mar", "gard", "stein", "hafen", "grad", "polis", "fior", "monte", "ria", "nia", "porte", "burgo", "valle", "costa", "alto", "verde", "dourada", "clara"];

export const genCityName = (r: () => number) => {
  const a = rPick(r, CITY_A);
  const b = rPick(r, CITY_B);
  const c = rPick(r, CITY_C);
  const name = a + b + c;
  return name.charAt(0).toUpperCase() + name.slice(1);
};
