import { create } from "zustand";
import type {
  GameState, GameEvent, ToolId, CivSnap, WorldStats, Battle,
} from "./types";
import {
  createGame, simStepYear, applyTool, impactMeteor,
  snapshotCivs, worldStats, getCapitalPos,
  type StepFlags,
} from "./simulation";
import { sfx } from "./sound";

/* ------------------------------------------------------------------ */
/*  Mutable heavy game state lives OUTSIDE React for performance       */
/* ------------------------------------------------------------------ */
let G: GameState | null = null;
export const getG = () => G;

let yearAcc = 0;
let uiAcc = 0;
let snapAcc = 1;
let lastApply: Record<string, number> = {};
let evtSoundAcc = 0;

/* camera shake impulse (read every frame by Scene) */
export const shakeRef = { amp: 0 };

export interface Versions {
  terrain: number;
  territory: number;
  cities: number;
  nature: number;
}

interface StoreState {
  phase: "title" | "game";
  seed: number;
  year: number;
  speed: number; // 0 = paused, 1, 2, 4
  tool: ToolId;
  brush: number;
  muted: boolean;
  civs: CivSnap[];
  selectedCiv: number | null;
  events: GameEvent[];
  battles: Battle[];
  stats: WorldStats;
  versions: Versions;
  fxVer: number;
  focus: { x: number; z: number; n: number } | null;
  minimapTick: number;
  helpOpen: boolean;

  start: () => void;
  setSpeed: (s: number) => void;
  setTool: (t: ToolId) => void;
  setBrush: (b: number) => void;
  toggleMute: () => void;
  toggleHelp: () => void;
  selectCiv: (id: number | null, focusIt?: boolean) => void;
  blessCiv: (id: number) => void;
  focusAt: (x: number, z: number) => void;
  tick: (dt: number) => void;
  applyToolAt: (tx: number, tz: number) => void;
  meteorImpact: (fxId: number) => void;
  removeFx: (fxId: number) => void;
}

const mergeFlags = (v: Versions, f: StepFlags): Versions => ({
  terrain: v.terrain + (f.terrain ? 1 : 0),
  territory: v.territory + (f.territory ? 1 : 0),
  cities: v.cities + (f.cities ? 1 : 0),
  nature: v.nature + (f.nature ? 1 : 0),
});

const EVT_SOUND: Record<string, "war" | "found" | "era" | "disaster" | "bless"> = {
  war: "war", found: "found", era: "era", disaster: "disaster",
  bless: "bless", fall: "war", conquer: "war",
};

function pushEvents(cur: GameEvent[], incoming: GameEvent[]): GameEvent[] {
  if (incoming.length === 0) return cur;
  const now = performance.now();
  if (now - evtSoundAcc > 600) {
    for (const e of incoming) {
      const k = EVT_SOUND[e.kind];
      if (k) { sfx.play(k); evtSoundAcc = now; break; }
    }
  }
  return [...incoming.slice(-6).reverse(), ...cur].slice(0, 40);
}

export const useStore = create<StoreState>((set, get) => ({
  phase: "title",
  seed: 0,
  year: -4200,
  speed: 1,
  tool: "observe",
  brush: 4,
  muted: false,
  civs: [],
  selectedCiv: null,
  events: [],
  battles: [],
  stats: { pop: 0, civs: 0, cities: 0, wars: 0, eraDist: [0, 0, 0, 0, 0] },
  versions: { terrain: 0, territory: 0, cities: 0, nature: 0 },
  fxVer: 0,
  focus: null,
  minimapTick: 0,
  helpOpen: false,

  start: () => {
    const seed = (Math.random() * 1e9) | 0;
    const { G: g, events } = createGame(seed);
    G = g;
    yearAcc = 0; snapAcc = 1; lastApply = {};
    set({
      phase: "game",
      seed,
      year: g.year,
      speed: 1,
      tool: "observe",
      selectedCiv: null,
      events: events.slice().reverse(),
      civs: snapshotCivs(g),
      battles: [],
      stats: worldStats(g),
      versions: { terrain: 1, territory: 1, cities: 1, nature: 1 },
      fxVer: 1,
      focus: { x: 0, z: 0, n: 1 },
      minimapTick: 1,
      helpOpen: false,
    });
    sfx.play("era");
  },

  setSpeed: (s) => set({ speed: s }),
  setTool: (t) => { set({ tool: t }); sfx.play("click"); },
  setBrush: (b) => set({ brush: b }),
  toggleMute: () => {
    const m = !get().muted;
    sfx.enabled = !m;
    set({ muted: m });
  },
  toggleHelp: () => { set({ helpOpen: !get().helpOpen }); sfx.play("click"); },

  selectCiv: (id, focusIt) => {
    set({ selectedCiv: id });
    if (id !== null) {
      sfx.play("select");
      if (focusIt && G) {
        const p = getCapitalPos(G, id);
        if (p) set({ focus: { x: p.x, z: p.z, n: Date.now() } });
      }
    }
  },

  blessCiv: (id) => {
    if (!G) return;
    const p = getCapitalPos(G, id);
    if (!p) return;
    const tx = Math.round(p.x + 48 - 0.5);
    const tz = Math.round(p.z + 48 - 0.5);
    const res = applyTool(G, "bless", tx, tz, 4);
    if (res.events.length) {
      sfx.play("bless");
      set({
        events: pushEvents(get().events, res.events),
        civs: snapshotCivs(G),
        fxVer: get().fxVer + (G.fx.length !== fxLenMemo ? 1 : 0),
      });
      fxLenMemo = G.fx.length;
    }
  },

  focusAt: (x, z) => set({ focus: { x, z, n: Date.now() } }),

  tick: (dt) => {
    const s = get();
    if (!G || s.phase !== "game" || s.speed === 0) return;
    yearAcc += dt * 2.1 * s.speed;
    let flags: StepFlags = { terrain: false, territory: false, cities: false, nature: false };
    const newEvents: GameEvent[] = [];
    let stepped = 0;
    while (yearAcc >= 1 && stepped < 12) {
      yearAcc -= 1;
      stepped++;
      const res = simStepYear(G);
      newEvents.push(...res.events);
      flags.terrain ||= res.flags.terrain;
      flags.territory ||= res.flags.territory;
      flags.cities ||= res.flags.cities;
      flags.nature ||= res.flags.nature;
    }

    uiAcc += dt;
    snapAcc += dt;
    const doSnap = snapAcc > 0.45;
    if (uiAcc > 0.05 || stepped > 0) {
      uiAcc = 0;
      let versions = s.versions;
      if (flags.terrain || flags.territory || flags.cities || flags.nature)
        versions = mergeFlags(versions, flags);
      set({
        year: G.year,
        versions,
        battles: stepped > 0 ? G.battles.map((b) => ({ ...b })) : s.battles,
        civs: doSnap ? snapshotCivs(G) : s.civs,
        stats: doSnap ? worldStats(G) : s.stats,
        events: pushEvents(s.events, newEvents),
        fxVer: s.fxVer + (G.fx.length !== fxLenMemo ? 1 : 0),
        minimapTick: doSnap ? s.minimapTick + 1 : s.minimapTick,
      });
      if (doSnap) { snapAcc = 0; fxLenMemo = G.fx.length; }
    }
  },

  applyToolAt: (tx, tz) => {
    const s = get();
    if (!G || s.phase !== "game") return;
    const now = performance.now();
    const instant = s.tool === "volcano" || s.tool === "meteor" || s.tool === "bless" || s.tool === "river";
    const key = instant ? `${s.tool}:${tx >> 2}:${tz >> 2}` : `${s.tool}:${tx >> 2}:${tz >> 2}:${Math.floor(now / 110)}`;
    if (lastApply[key] && now - lastApply[key] < (instant ? 500 : 90)) return;
    lastApply[key] = now;

    const res = applyTool(G, s.tool, tx, tz, s.brush);
    let needsSet = false;
    const partial: Partial<StoreState> = {};
    if (res.flags.terrain || res.flags.territory || res.flags.cities || res.flags.nature) {
      partial.versions = mergeFlags(s.versions, res.flags);
      partial.minimapTick = s.minimapTick + 1;
      needsSet = true;
    }
    if (res.events.length) {
      partial.events = pushEvents(s.events, res.events);
      partial.civs = snapshotCivs(G);
      partial.stats = worldStats(G);
      needsSet = true;
    }
    if (G.fx.length !== fxLenMemo) {
      partial.fxVer = s.fxVer + 1;
      fxLenMemo = G.fx.length;
      needsSet = true;
    }
    if (s.tool === "volcano") { sfx.play("disaster"); shakeRef.amp = Math.max(shakeRef.amp, 0.5); }
    if (s.tool === "meteor") sfx.play("war");
    if (s.tool === "bless" && res.events.length) sfx.play("bless");
    if (needsSet) set(partial);
  },

  meteorImpact: (fxId) => {
    if (!G) return;
    const res = impactMeteor(G, fxId);
    shakeRef.amp = Math.max(shakeRef.amp, 1.0);
    sfx.play("impact");
    const s = get();
    set({
      versions: mergeFlags(s.versions, res.flags),
      events: pushEvents(s.events, res.events),
      civs: snapshotCivs(G),
      stats: worldStats(G),
      minimapTick: s.minimapTick + 1,
    });
  },

  removeFx: (fxId) => {
    if (!G) return;
    G.fx = G.fx.filter((f) => f.id !== fxId);
    fxLenMemo = G.fx.length;
    set({ fxVer: get().fxVer + 1 });
  },
}));

let fxLenMemo = 0;
