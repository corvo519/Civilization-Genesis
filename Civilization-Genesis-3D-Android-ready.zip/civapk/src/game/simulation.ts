import { mulberry32, genCivName, genCityName } from "./rng";
import {
  W, H, SEA, idx, tileToWorld, ERAS, CIV_COLORS,
  CAT_WATER, CAT_SAND, CAT_GRASS, CAT_FOREST, CAT_ROCK, CAT_SNOW,
  RES_GOLD, RES_IRON, RES_GEM,
  type GameState, type Civ, type City, type GameEvent, type ToolId,
  type CivSnap, type WorldStats,
} from "./types";
import {
  generateWorld, heightBlob, plantForest, placeResources, traceRiver,
  volcanoRaise, craterCarve, scorchArea, decayScorch,
} from "./world";

let evtId = 1;
const mkEvt = (year: number, kind: GameEvent["kind"], text: string, civ?: number): GameEvent =>
  ({ id: evtId++, year, kind, text, civ });

const LEVEL_POP = [150, 700, 2400, 8000];
const cityCap = (c: City, era: number) => 260 * c.level * (1 + era * 0.75);

/* ============================================================ Creation */
export function createGame(seed: number): { G: GameState; events: GameEvent[] } {
  const world = generateWorld(seed);
  const G: GameState = {
    world,
    year: -4200,
    civs: [],
    cities: [],
    wars: [],
    battles: [],
    fx: [],
    rng: mulberry32(seed ^ 0xabcdef),
    nextCivId: 0,
    nextCityId: 1,
    nextWarId: 1,
    nextBattleId: 1,
    nextFxId: 1,
    usedNames: new Set(),
  };

  const events: GameEvent[] = [
    mkEvt(G.year, "genesis", "O mundo desperta das águas primordiais. A terra aguarda seus primeiros povos."),
  ];

  // spawn civilizations on good grassland, spread apart
  const capitals: number[] = [];
  let attempts = 0;
  const want = 5;
  while (capitals.length < want && attempts++ < 4000) {
    const x = 4 + Math.floor(G.rng() * (W - 8));
    const z = 4 + Math.floor(G.rng() * (H - 8));
    const i = idx(x, z);
    const cat = world.cat[i];
    if (!(cat === CAT_GRASS || cat === CAT_FOREST)) continue;
    if (world.height[i] > 0.52) continue;
    let ok = true;
    for (const c of capitals) {
      const dx = (c % W) - x, dz = Math.floor(c / W) - z;
      if (dx * dx + dz * dz < 20 * 20) { ok = false; break; }
    }
    if (!ok) continue;
    capitals.push(i);
  }

  capitals.forEach((tile) => {
    const civ = addCiv(G, tile);
    expandCiv(G, civ, 16);
    const city = foundCity(G, civ, tile, true);
    civ.pop = 130;
    if (city) {
      events.push(mkEvt(G.year, "found", `A tribo de ${civ.name} ergue suas primeiras tendas em ${city.name}.`, civ.id));
    }
  });

  return { G, events };
}

function addCiv(G: GameState, tile: number): Civ {
  let name = genCivName(G.rng);
  while (G.usedNames.has(name)) name = genCivName(G.rng);
  G.usedNames.add(name);
  const id = G.nextCivId++;
  const civ: Civ = {
    id,
    name,
    color: CIV_COLORS[id % CIV_COLORS.length],
    founded: G.year,
    era: 0,
    tech: 0,
    pop: 80,
    military: 10,
    blessed: 0,
    territory: new Set(),
    cities: [],
    rel: new Map(),
    allies: new Set(),
    alive: true,
    nGrass: 0, nForest: 0, nRiver: 0, nCoast: 0, nRock: 0, nGold: 0, nIron: 0, nGem: 0,
    peakPop: 0,
  };
  G.civs.push(civ);
  setOwner(G, tile, id);
  return civ;
}

const getCiv = (G: GameState, id: number) => G.civs.find((c) => c.id === id);
const getCity = (G: GameState, id: number) => G.cities.find((c) => c.id === id);

/* ============================================================ Ownership */
export function setOwner(G: GameState, tile: number, civId: number) {
  const w = G.world;
  const prev = w.owner[tile];
  if (prev === civId) return;
  const cat = w.cat[tile];
  const adjust = (civ: Civ, dir: number) => {
    if (cat === CAT_GRASS) civ.nGrass += dir;
    else if (cat === CAT_FOREST) civ.nForest += dir;
    else if (cat === CAT_ROCK || cat === CAT_SNOW) civ.nRock += dir;
    if (w.river[tile]) civ.nRiver += dir;
    if (w.res[tile] === RES_GOLD) civ.nGold += dir;
    else if (w.res[tile] === RES_IRON) civ.nIron += dir;
    else if (w.res[tile] === RES_GEM) civ.nGem += dir;
    // coast check
    const x = tile % W, z = Math.floor(tile / W);
    if (
      (x > 0 && w.cat[idx(x - 1, z)] === CAT_WATER) ||
      (x < W - 1 && w.cat[idx(x + 1, z)] === CAT_WATER) ||
      (z > 0 && w.cat[idx(x, z - 1)] === CAT_WATER) ||
      (z < H - 1 && w.cat[idx(x, z + 1)] === CAT_WATER)
    ) civ.nCoast += dir;
  };
  if (prev >= 0) {
    const p = getCiv(G, prev);
    if (p) { p.territory.delete(tile); adjust(p, -1); }
  }
  w.owner[tile] = civId;
  if (civId >= 0) {
    const n = getCiv(G, civId);
    if (n) { n.territory.add(tile); adjust(n, 1); }
  }
  // city on the tile changes hands / is destroyed
  const cid = w.city[tile];
  if (cid >= 0) {
    const city = getCity(G, cid);
    if (city && city.civ !== civId) {
      const oldCiv = getCiv(G, city.civ);
      if (oldCiv) oldCiv.cities = oldCiv.cities.filter((c) => c !== cid);
      if (civId >= 0) {
        const nc = getCiv(G, civId);
        if (nc) nc.cities.push(cid);
        city.civ = civId;
        city.pop = Math.max(60, city.pop * 0.7);
        if (nc && oldCiv)
          pendingEvents.push(mkEvt(G.year, "conquer", `${nc.name} conquistou a cidade de ${city.name} de ${oldCiv.name}!`, civId));
      } else {
        destroyCity(G, cid);
      }
    }
  }
}

/* events generated inside ownership changes (war captures) */
let pendingEvents: GameEvent[] = [];
const drainPending = () => {
  const e = pendingEvents;
  pendingEvents = [];
  return e;
};

function destroyCity(G: GameState, cityId: number) {
  const city = getCity(G, cityId);
  if (!city) return;
  const civ = getCiv(G, city.civ);
  if (civ) civ.cities = civ.cities.filter((c) => c !== cityId);
  G.world.city[city.tile] = -1;
  G.cities = G.cities.filter((c) => c.id !== cityId);
}

/* ============================================================ Expansion & cities */
function desirability(G: GameState, tile: number): number {
  const w = G.world;
  const cat = w.cat[tile];
  if (cat === CAT_WATER || w.height[tile] > 0.86) return -1;
  let s = 0;
  if (cat === CAT_GRASS) s = 3;
  else if (cat === CAT_FOREST) s = 2.6;
  else if (cat === CAT_SAND) s = 1;
  else if (cat === CAT_ROCK) s = 0.45;
  else if (cat === CAT_SNOW) s = 0.15;
  if (w.river[tile]) s += 2;
  if (w.res[tile]) s += 3;
  if (w.scorch[tile] > 0.4) s *= 0.25;
  return s;
}

const territoryCap = (c: Civ) => 42 + c.cities.length * 36 + c.pop / 600 + c.era * 34;

export function expandCiv(G: GameState, civ: Civ, k: number): boolean {
  const w = G.world;
  let any = false;
  const terr = civ.territory;
  if (terr.size === 0 || terr.size >= territoryCap(civ)) return false;
  const seafaring = civ.era >= 2; // medieval peoples build boats and hop straits
  for (let n = 0; n < k; n++) {
    let best = -1, bestScore = 0;
    let sampled = 0;
    for (const t of terr) {
      if (++sampled > 340) break;
      const x = t % W, z = Math.floor(t / W);
      const dirs = seafaring
        ? ([[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1], [2, 0], [-2, 0], [0, 2], [0, -2]] as const)
        : ([[1, 0], [-1, 0], [0, 1], [0, -1]] as const);
      for (const [dx, dz] of dirs) {
        const nx = x + dx, nz = z + dz;
        if (nx < 1 || nz < 1 || nx >= W - 2 || nz >= H - 2) continue;
        const ni = idx(nx, nz);
        if (w.owner[ni] !== -1) continue;
        // distant hops must cross water, not land bridges
        if (Math.abs(dx) + Math.abs(dz) > 1) {
          const midCat = w.cat[idx(x + Math.sign(dx), z + Math.sign(dz))];
          if (midCat !== CAT_WATER) continue;
        }
        const s = desirability(G, ni);
        if (s <= 0) continue;
        const jitter = G.rng() * 0.8;
        if (s + jitter > bestScore) { bestScore = s + jitter; best = ni; }
      }
    }
    if (best < 0) break;
    setOwner(G, best, civ.id);
    any = true;
  }
  return any;
}

export function foundCity(G: GameState, civ: Civ, forceTile?: number, capital = false): City | null {
  const w = G.world;
  let tile = forceTile ?? -1;
  if (tile < 0) {
    let best = -1, bestScore = 0;
    let tries = 0;
    for (const t of civ.territory) {
      if (++tries > 400) break;
      if (w.city[t] !== -1) continue;
      const h = w.height[t];
      if (h < SEA + 0.015 || h > 0.62) continue;
      const x = t % W, z = Math.floor(t / W);
      let minD = Infinity;
      for (const cid of civ.cities) {
        const c = getCity(G, cid);
        if (!c) continue;
        const dx = (c.tile % W) - x, dz = Math.floor(c.tile / W) - z;
        minD = Math.min(minD, dx * dx + dz * dz);
      }
      if (minD < 36) continue;
      const s = desirability(G, t) + G.rng() * 2;
      if (s > bestScore) { bestScore = s; best = t; }
    }
    tile = best;
  }
  if (tile < 0) return null;
  let name = genCityName(G.rng);
  while (G.usedNames.has(name)) name = genCityName(G.rng);
  G.usedNames.add(name);
  const id = G.nextCityId++;
  const city: City = {
    id, civ: civ.id, tile, name,
    pop: capital ? 90 : 55 + G.rng() * 60,
    level: 1, founded: G.year, capital,
  };
  G.cities.push(city);
  civ.cities.push(id);
  w.city[tile] = id;
  if (w.owner[tile] !== civ.id) setOwner(G, tile, civ.id);
  return city;
}

/* ============================================================ War & diplomacy */
function sharesBorder(G: GameState, a: Civ, b: Civ): boolean {
  const w = G.world;
  let n = 0;
  for (const t of a.territory) {
    if (++n > 500) break;
    const x = t % W, z = Math.floor(t / W);
    if (x > 0 && w.owner[idx(x - 1, z)] === b.id) return true;
    if (x < W - 1 && w.owner[idx(x + 1, z)] === b.id) return true;
    if (z > 0 && w.owner[idx(x, z - 1)] === b.id) return true;
    if (z < H - 1 && w.owner[idx(x, z + 1)] === b.id) return true;
  }
  return false;
}

function captureFromEnemy(G: GameState, att: Civ, def: Civ, k: number): number[] {
  const w = G.world;
  const captured: number[] = [];
  let sampled = 0;
  outer: for (const t of def.territory) {
    if (++sampled > 700) break;
    const x = t % W, z = Math.floor(t / W);
    const near =
      (x > 0 && w.owner[idx(x - 1, z)] === att.id) ||
      (x < W - 1 && w.owner[idx(x + 1, z)] === att.id) ||
      (z > 0 && w.owner[idx(x, z - 1)] === att.id) ||
      (z < H - 1 && w.owner[idx(x, z + 1)] === att.id);
    if (!near) continue;
    def.territory.delete(t);
    setOwner(G, t, att.id);
    captured.push(t);
    if (captured.length >= k) break outer;
  }
  return captured;
}

function spawnBattle(G: GameState, tile: number, a: number, b: number) {
  if (G.battles.length >= 14) G.battles.shift();
  G.battles.push({ id: G.nextBattleId++, tile, a, b, t0: G.year, ttl: 1.6 });
}

function killCiv(G: GameState, civ: Civ, evts: GameEvent[], victorId: number | null) {
  if (!civ.alive) return;
  civ.alive = false;
  const victor = victorId !== null ? getCiv(G, victorId) : undefined;
  const terr = Array.from(civ.territory);
  for (const t of terr) setOwner(G, t, victor ? victor.id : -1);
  for (const cid of [...civ.cities]) {
    if (victor) {
      const c = getCity(G, cid);
      if (c) { c.civ = victor.id; victor.cities.push(cid); }
    } else destroyCity(G, cid);
  }
  civ.cities = [];
  G.wars = G.wars.filter((wr) => wr.a !== civ.id && wr.b !== civ.id);
  for (const o of G.civs) { o.allies.delete(civ.id); o.rel.delete(civ.id); }
  if (victor) evts.push(mkEvt(G.year, "fall", `O império de ${civ.name} caiu diante de ${victor.name}. Suas terras foram anexadas.`, victor.id));
  else evts.push(mkEvt(G.year, "fall", `A civilização de ${civ.name} desapareceu do mundo.`, civ.id));
}

export interface StepFlags {
  terrain: boolean;
  territory: boolean;
  cities: boolean;
  nature: boolean;
}

export function simStepYear(G: GameState): { events: GameEvent[]; flags: StepFlags } {
  const evts: GameEvent[] = [];
  const flags: StepFlags = { terrain: false, territory: false, cities: false, nature: false };
  G.year += 1;

  if (decayScorch(G.world, 1)) flags.terrain = true;
  G.battles = G.battles.filter((b) => G.year - b.t0 < b.ttl);

  const alive = G.civs.filter((c) => c.alive);

  /* --- per-civ growth --- */
  for (const civ of alive) {
    const foodCap = civ.nGrass * 520 + civ.nRiver * 900 + civ.nCoast * 300 + civ.nForest * 260;
    const cityCapTotal = civ.cities.reduce((s, cid) => {
      const c = getCity(G, cid);
      return c ? s + cityCap(c, civ.era) : s;
    }, 0);
    const cap = Math.max(130, Math.min(cityCapTotal + civ.territory.size * 18, foodCap * 2.2 + 200));
    const over = civ.pop / Math.max(1, cap);
    const r =
      0.011 + civ.era * 0.002 + (civ.blessed > 0 ? 0.02 : 0) +
      (over < 0.85 ? 0.004 : over <= 1 ? 0 : -0.06);
    civ.pop = Math.max(40, Math.min(cap, civ.pop * (1 + r)));
    civ.peakPop = Math.max(civ.peakPop, civ.pop);
    if (civ.blessed > 0) civ.blessed--;

    // cities absorb 60% of population
    const cities = civ.cities.map((c) => getCity(G, c)).filter(Boolean) as City[];
    const sumCityPop = cities.reduce((s, c) => s + c.pop, 0);
    if (cities.length > 0) {
      const target = Math.min(civ.pop * 0.62, cities.reduce((s, c) => s + cityCap(c, civ.era) * 1.5, 0));
      const f = sumCityPop > 1 ? target / sumCityPop : 1;
      for (const c of cities) {
        c.pop = Math.max(40, c.pop * (1 + r * 0.9) * Math.min(f, 1.4));
        const lv = 1 + LEVEL_POP.filter((t) => c.pop >= t).length;
        if (lv !== c.level) { c.level = Math.min(5, lv); flags.cities = true; }
      }
    }

    // technology & eras
    civ.tech += 0.33 + cities.length * 0.05 + civ.pop * 0.000006 + (civ.blessed > 0 ? 1.4 : 0);
    if (civ.era < 4 && civ.tech >= ERAS[civ.era].techNeed) {
      civ.tech = 0;
      civ.era++;
      flags.cities = true;
      evts.push(mkEvt(G.year, "era", `${civ.name} avança para a ${ERAS[civ.era].name}!`, civ.id));
    }

    civ.military = Math.round(
      (12 + civ.pop * 0.014 + cities.length * 10) *
      (1 + civ.era * 0.6) *
      (1 + civ.nIron * 0.05 + civ.nRock * 0.012) *
      (civ.blessed > 0 ? 1.18 : 1)
    );

    // expansion
    if (expandCiv(G, civ, 1 + Math.floor(civ.era / 2) + (civ.blessed > 0 ? 2 : 0))) flags.territory = true;

    // founding new cities
    const threshold = 320 * Math.pow(cities.length + 1, 1.7);
    if (civ.pop > threshold && cities.length < 1 + civ.era * 2 + Math.floor(civ.territory.size / 150)) {
      const city = foundCity(G, civ);
      if (city) {
        civ.pop = Math.max(40, civ.pop - city.pop * 0.8);
        flags.cities = true;
        flags.territory = true;
        evts.push(mkEvt(G.year, "found", `${civ.name} fundou a cidade de ${city.name}.`, civ.id));
      }
    }
  }

  /* --- diplomacy --- */
  for (let i = 0; i < alive.length; i++) {
    for (let j = i + 1; j < alive.length; j++) {
      const a = alive[i], b = alive[j];
      const atWar = G.wars.some((wr) => (wr.a === a.id && wr.b === b.id) || (wr.a === b.id && wr.b === a.id));
      if (atWar) continue;
      const allied = a.allies.has(b.id);
      let rel = a.rel.get(b.id) ?? (G.rng() * 30 - 12);
      const neighbor = sharesBorder(G, a, b);
      if (neighbor && !allied) rel -= 1.35 + Math.max(a.era, b.era) * 0.25 + G.rng() * 1.6;
      else if (!neighbor) rel += rel < 12 ? 0.55 : -0.35; // distant peoples drift toward trade & trust
      if (a.blessed > 0 || b.blessed > 0) rel += 0.6;
      rel += G.rng() * 4 - 2;
      rel = Math.max(-100, Math.min(100, rel));
      a.rel.set(b.id, rel);
      b.rel.set(a.id, rel);

      if (allied && G.rng() < 0.015) {
        a.allies.delete(b.id); b.allies.delete(a.id);
      } else if (!allied && rel > 58 && G.rng() < 0.08) {
        a.allies.add(b.id); b.allies.add(a.id);
        evts.push(mkEvt(G.year, "ally", `${a.name} e ${b.name} firmam uma aliança.`, a.id));
      } else if (!allied && neighbor && rel <= -50 && G.wars.length < 6 && G.rng() < 0.3) {
        const att = a.military >= b.military ? a : b;
        const def = att === a ? b : a;
        if (att.military > def.military * 0.9) {
          G.wars.push({ a: att.id, b: def.id, since: G.year, dur: 0, score: 0, id: G.nextWarId++ });
          evts.push(mkEvt(G.year, "war", `${att.name} declara guerra a ${def.name}!`, att.id));
        }
      }
    }
  }

  /* --- wars --- */
  for (const war of [...G.wars]) {
    const a = getCiv(G, war.a), b = getCiv(G, war.b);
    if (!a || !b || !a.alive || !b.alive) continue;
    war.dur++;
    const aStrong = a.military >= b.military;
    const att = aStrong ? a : b;
    const def = aStrong ? b : a;
    const k = 1 + Math.floor(att.era * 1.1) + (att.military > def.military * 1.7 ? 2 : 0);
    const captured = captureFromEnemy(G, att, def, k);
    if (captured.length > 0) {
      flags.territory = true;
      war.score += (att === a ? 1 : -1) * captured.length;
      if (G.rng() < 0.85) {
        const t = captured[Math.floor(G.rng() * captured.length)];
        spawnBattle(G, t, att.id, def.id);
      }
    }
    def.pop = Math.max(30, def.pop * (0.975 - Math.min(0.02, att.military / Math.max(1, def.military) * 0.004)));
    att.pop *= 0.994;

    // genocide by land
    if (def.territory.size <= 4 || (def.cities.length === 0 && def.pop < 70)) {
      killCiv(G, def, evts, att.id);
      flags.territory = true; flags.cities = true;
      G.wars = G.wars.filter((x) => x.id !== war.id);
      continue;
    }
    // a winner annexes after long dominance
    if (war.dur > 7 && Math.abs(war.score) > 22) {
      evts.push(mkEvt(G.year, "peace", `${att.name} e ${def.name} assinam a paz após anos de guerra.`, att.id));
      att.rel.set(def.id, -18);
      def.rel.set(att.id, -18);
      G.wars = G.wars.filter((x) => x.id !== war.id);
    } else if (war.dur > 5 && G.rng() < 0.16) {
      evts.push(mkEvt(G.year, "peace", `${a.name} e ${b.name} chegam a um cessar-fogo.`, a.id));
      a.rel.set(b.id, -12);
      b.rel.set(a.id, -12);
      G.wars = G.wars.filter((x) => x.id !== war.id);
    }
  }

  /* --- collapse check --- */
  for (const civ of alive) {
    if (civ.territory.size === 0 || (civ.cities.length === 0 && civ.pop < 55)) {
      const enemyWar = G.wars.find((wr) => wr.a === civ.id || wr.b === civ.id);
      killCiv(G, civ, evts, enemyWar ? (enemyWar.a === civ.id ? enemyWar.b : enemyWar.a) : null);
      flags.territory = true; flags.cities = true;
    }
  }

  evts.push(...drainPending());
  return { events: evts, flags };
}

/* ============================================================ God tools */
export function applyTool(
  G: GameState,
  tool: ToolId,
  tx: number,
  tz: number,
  brush: number
): { events: GameEvent[]; flags: StepFlags } {
  const w = G.world;
  const events: GameEvent[] = [];
  const flags: StepFlags = { terrain: false, territory: false, cities: false, nature: false };
  const i = idx(tx, tz);

  switch (tool) {
    case "mountain":
      heightBlob(w, tx, tz, brush, 0.05);
      flags.terrain = true; flags.nature = true;
      drownedSweep(G, events, flags);
      break;
    case "ocean":
      heightBlob(w, tx, tz, brush, -0.065);
      flags.terrain = true; flags.nature = true;
      drownedSweep(G, events, flags);
      break;
    case "river":
      if (traceRiver(w, tx, tz)) { flags.terrain = true; }
      break;
    case "forest":
      plantForest(w, tx, tz, brush, G.rng);
      flags.nature = true; flags.terrain = true;
      break;
    case "resource":
      placeResources(w, tx, tz, brush, G.rng);
      flags.nature = true;
      break;
    case "bless": {
      const civId = w.owner[i] >= 0 ? w.owner[i] : (w.city[i] >= 0 ? (getCity(G, w.city[i])?.civ ?? -1) : -1);
      const civ = civId >= 0 ? getCiv(G, civId) : undefined;
      if (civ && civ.alive) {
        civ.blessed = 30;
        events.push(mkEvt(G.year, "bless", `Uma luz dourada banha ${civ.name}. O povo floresce abençoado!`, civ.id));
        const cap = civ.cities.map((c) => getCity(G, c)).find((c) => c?.capital);
        const t = cap ? cap.tile : Array.from(civ.territory)[0];
        if (t !== undefined) {
          const p = tileToWorld(t);
          G.fx.push({ id: G.nextFxId++, type: "blessfx", x: p.x, y: w.height[t] * 13, z: p.z, t0: performance.now(), dur: 2600 });
        }
      }
      break;
    }
    case "volcano": {
      if (w.height[i] < SEA) break;
      const capitalsLost = destroyAround(G, tx, tz, 3.4, events, "vulcão");
      volcanoRaise(w, tx, tz, 3.6);
      w.volcanoes[w.volcanoes.length - 1].born = G.year;
      for (const civ of G.civs) {
        if (!civ.alive) continue;
        const cap = civ.cities.map((c) => getCity(G, c)).find((c) => c?.capital);
        if (cap) {
          const dx = (cap.tile % W) - tx, dz = Math.floor(cap.tile / W) - tz;
          if (dx * dx + dz * dz < 64) civ.pop *= 0.86;
        }
      }
      clearOwnersAround(G, tx, tz, 4.4);
      flags.terrain = true; flags.nature = true; flags.territory = true; flags.cities = capitalsLost;
      events.push(mkEvt(G.year, "disaster", "A terra ruge: um vulcão entra em erupção, cobrindo o céu de cinzas!"));
      const p = tileToWorld(i);
      G.fx.push({ id: G.nextFxId++, type: "eruption", x: p.x, y: w.height[i] * 13, z: p.z, t0: performance.now(), dur: 5200 });
      break;
    }
    case "meteor": {
      const p = tileToWorld(i);
      G.fx.push({ id: G.nextFxId++, type: "meteor", x: p.x, y: w.height[i] * 13, z: p.z, t0: performance.now(), dur: 950 });
      break;
    }
    case "observe":
      break;
  }
  return { events, flags };
}

export function impactMeteor(G: GameState, fxId: number): { events: GameEvent[]; flags: StepFlags } {
  const events: GameEvent[] = [];
  const flags: StepFlags = { terrain: true, territory: true, cities: false, nature: true };
  const fx = G.fx.find((f) => f.id === fxId);
  if (!fx || fx.hit) return { events, flags };
  fx.hit = true;
  const tx = Math.round(fx.x + W / 2), tz = Math.round(fx.z + H / 2);
  const destroyed = destroyAround(G, tx, tz, 3.2, events, "meteoro");
  flags.cities = destroyed;
  craterCarve(G.world, tx, tz, 3.4);
  scorchArea(G.world, tx, tz, 5, 0.9);
  clearOwnersAround(G, tx, tz, 4);
  events.push(mkEvt(G.year, "disaster", "Um meteoro rasga os céus e devasta a região!"));
  return { events, flags };
}

function destroyAround(G: GameState, tx: number, tz: number, r: number, events: GameEvent[], cause: string): boolean {
  let any = false;
  for (const city of [...G.cities]) {
    const dx = (city.tile % W) - tx, dz = Math.floor(city.tile / W) - tz;
    const d = Math.hypot(dx, dz);
    if (d <= r) {
      const civ = getCiv(G, city.civ);
      events.push(mkEvt(G.year, "disaster", `A cidade de ${city.name}${civ ? ` (${civ.name})` : ""} foi destruída pelo ${cause}.`, city.civ));
      if (civ) civ.pop = Math.max(40, civ.pop * 0.8);
      destroyCity(G, city.id);
      any = true;
    } else if (d <= r * 2.2) {
      city.pop *= 0.75;
    }
  }
  return any;
}

function clearOwnersAround(G: GameState, tx: number, tz: number, r: number) {
  const w = G.world;
  const r2 = r * r;
  for (let z = Math.floor(tz - r); z <= tz + r; z++)
    for (let x = Math.floor(tx - r); x <= tx + r; x++) {
      if (x < 1 || z < 1 || x >= W - 2 || z >= H - 2) continue;
      const dx = x - tx, dz = z - tz;
      if (dx * dx + dz * dz > r2) continue;
      const t = idx(x, z);
      if (w.owner[t] >= 0) setOwner(G, t, -1);
    }
}

function drownedSweep(G: GameState, events: GameEvent[], flags: StepFlags) {
  const w = G.world;
  for (let t = 0; t < W * H; t++) {
    if (w.height[t] < SEA && w.owner[t] >= 0) {
      setOwner(G, t, -1);
      flags.territory = true;
    }
    if (w.height[t] < SEA && w.city[t] >= 0) {
      const city = getCity(G, w.city[t]);
      if (city) {
        events.push(mkEvt(G.year, "disaster", `A cidade de ${city.name} foi engolida pelo mar.`, city.civ));
        destroyCity(G, city.id);
        flags.cities = true;
      }
    }
  }
}

/* ============================================================ Snapshots */
export function snapshotCivs(G: GameState): CivSnap[] {
  return G.civs
    .filter((c) => c.alive)
    .map((c) => {
      const cities = c.cities.map((id) => getCity(G, id)).filter(Boolean) as City[];
      const capital = cities.find((x) => x.capital) ?? cities[0];
      const wars = G.wars.filter((wr) => wr.a === c.id || wr.b === c.id);
      const enemies = wars
        .map((wr) => getCiv(G, wr.a === c.id ? wr.b : wr.a))
        .filter(Boolean)
        .map((x) => ({ id: x!.id, name: x!.name, color: x!.color }));
      const allies = Array.from(c.allies)
        .map((id) => getCiv(G, id))
        .filter((x) => x && x.alive)
        .map((x) => ({ id: x!.id, name: x!.name, color: x!.color }));
      return {
        id: c.id, name: c.name, color: c.color, era: c.era, tech: c.tech,
        pop: Math.round(c.pop), military: c.military, blessed: c.blessed,
        territorySize: c.territory.size, citiesCount: cities.length,
        capital: capital ? capital.id : -1, founded: c.founded,
        wars: wars.length, enemies, allies,
      };
    })
    .sort((a, b) => b.pop - a.pop);
}

export function worldStats(G: GameState): WorldStats {
  const eraDist = [0, 0, 0, 0, 0];
  let pop = 0, civs = 0;
  for (const c of G.civs) if (c.alive) { pop += c.pop; civs++; eraDist[c.era]++; }
  return { pop: Math.round(pop), civs, cities: G.cities.length, wars: G.wars.length, eraDist };
}

export function getCapitalPos(G: GameState, civId: number): { x: number; z: number } | null {
  const civ = getCiv(G, civId);
  if (!civ) return null;
  const cities = civ.cities.map((id) => getCity(G, id)).filter(Boolean) as City[];
  const capital = cities.find((c) => c.capital) ?? cities[0];
  if (!capital) {
    const t = Array.from(civ.territory)[0];
    if (t === undefined) return null;
    return tileToWorld(t);
  }
  return tileToWorld(capital.tile);
}

export function getCityAtTile(G: GameState, tile: number): City | null {
  const id = G.world.city[tile];
  return id >= 0 ? getCity(G, id) ?? null : null;
}

export { getCity, getCiv };
