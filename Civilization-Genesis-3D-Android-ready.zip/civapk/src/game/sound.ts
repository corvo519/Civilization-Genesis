// Tiny WebAudio synth for game feedback — no assets needed

type SoundKind = "click" | "found" | "war" | "era" | "disaster" | "bless" | "impact" | "select";

class SoundFX {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  enabled = true;
  private lastPlay: Record<string, number> = {};

  private ensure() {
    if (!this.ctx) {
      try {
        this.ctx = new AudioContext();
        this.master = this.ctx.createGain();
        this.master.gain.value = 0.14;
        this.master.connect(this.ctx.destination);
      } catch {
        /* audio unsupported */
      }
    }
    if (this.ctx?.state === "suspended") void this.ctx.resume();
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, delay = 0, slideTo?: number) {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g).connect(this.master);
    osc.start(t);
    osc.stop(t + dur + 0.05);
  }

  private noise(dur: number, vol: number, cutoff: number, delay = 0) {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime + delay;
    const len = Math.floor(this.ctx.sampleRate * dur);
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = cutoff;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(filter).connect(g).connect(this.master);
    src.start(t);
  }

  play(kind: SoundKind) {
    if (!this.enabled) return;
    // throttle identical sounds
    const now = performance.now();
    if (now - (this.lastPlay[kind] ?? 0) < 90) return;
    this.lastPlay[kind] = now;
    this.ensure();
    switch (kind) {
      case "click":
        this.tone(660, 0.06, "triangle", 0.5);
        break;
      case "select":
        this.tone(520, 0.08, "sine", 0.4);
        this.tone(780, 0.1, "sine", 0.3, 0.04);
        break;
      case "found":
        this.tone(392, 0.14, "triangle", 0.5);
        this.tone(523, 0.16, "triangle", 0.45, 0.09);
        this.tone(659, 0.22, "triangle", 0.4, 0.18);
        break;
      case "era":
        [523, 659, 784, 1046].forEach((f, i) => this.tone(f, 0.3, "sine", 0.35, i * 0.1));
        break;
      case "war":
        this.tone(110, 0.4, "sawtooth", 0.5, 0, 60);
        this.noise(0.3, 0.25, 400);
        break;
      case "bless":
        [880, 1108, 1318].forEach((f, i) => this.tone(f, 0.4, "sine", 0.28, i * 0.08));
        break;
      case "disaster":
        this.tone(70, 1.1, "sine", 0.7, 0, 38);
        this.noise(1.0, 0.4, 320);
        break;
      case "impact":
        this.noise(0.7, 0.6, 240);
        this.tone(55, 0.8, "sine", 0.8, 0, 30);
        break;
    }
  }
}

export const sfx = new SoundFX();
