// Core types, constants, era & tool definitions

export const W = 96; // grid width (tiles)
export const H = 96; // grid height (tiles)
export const N = W * H;
export const SEA = 0.33; // sea level (0..1 normalized height)
export const HG = 13; // world Y scale for height
export const seaY = SEA * HG;

export const idx = (x: number, z: number) => z * W + x;
export const inB = (x: number, z: number) => x >= 1 && z >= 1 && x < W - 2 && z < H - 2;
export const tileToWorld = (t: number) => ({
  x: (t % W) - W / 2 + 0.5,
  z: Math.floor(t / W) - H / 2 + 0.5,
});

// tile categories
export const CAT_WATER = 0;
export const CAT_SAND = 1;
export const CAT_GRASS = 2;
export const CAT_FOREST = 3;
export const CAT_ROCK = 4;
export const CAT_SNOW = 5;

export const RES_NONE = 0;
export const RES_GOLD = 1;
export const RES_IRON = 2;
export const RES_GEM = 3;

/* ------------------------------------------------ Eras */
export interface EraDef {
  name: string;
  color: string;
  techNeed: number; // tech points required to leave this era
}
export const ERAS: EraDef[] = [
  { name: "Era Primitiva", color: "#d9a066", techNeed: 150 },
  { name: "Era Agrícola", color: "#a3c14a", techNeed: 420 },
  { name: "Era Medieval", color: "#8ea8c3", techNeed: 760 },
  { name: "Era Industrial", color: "#d08c60", techNeed: 1150 },
  { name: "Era Tecnológica", color: "#5be3ff", techNeed: Infinity },
];

/* ------------------------------------------------ Tools */
export type ToolId =
  | "observe"
  | "mountain"
  | "ocean"
  | "river"
  | "forest"
  | "resource"
  | "bless"
  | "volcano"
  | "meteor";

/* ------------------------------------------------ Entities */
export interface World {
  seed: number;
  height: Float32Array;
  moist: Float32Array;
  forest: Uint8Array;
  river: Uint8Array;
  res: Uint8Array;
  owner: Int16Array; // civ id or -1
  city: Int16Array; // city id or -1
  scorch: Float32Array; // 0..1 heat (fires / destruction)
  cat: Uint8Array; // CAT_*
  volcanoes: { tile: number; born: number }[];
}

export interface Civ {
  id: number;
  name: string;
  color: string;
  founded: number;
  era: number;
  tech: number;
  pop: number;
  military: number;
  blessed: number; // years remaining
  territory: Set<number>;
  cities: number[];
  rel: Map<number, number>;
  allies: Set<number>;
  alive: boolean;
  // incremental resource counters
  nGrass: number;
  nForest: number;
  nRiver: number;
  nCoast: number;
  nRock: number;
  nGold: number;
  nIron: number;
  nGem: number;
  peakPop: number;
}

export interface City {
  id: number;
  civ: number;
  tile: number;
  name: string;
  pop: number;
  level: number;
  founded: number;
  capital: boolean;
}

export interface War {
  a: number;
  b: number;
  since: number;
  dur: number;
  score: number; // >0 favoring a
  id: number;
}

export interface Battle {
  id: number;
  tile: number;
  a: number;
  b: number;
  t0: number; // year when spawned
  ttl: number; // years
}

export interface FxItem {
  id: number;
  type: "meteor" | "blessfx" | "eruption";
  x: number;
  y: number;
  z: number;
  t0: number; // ms performance-based (works while paused)
  dur: number; // ms
  hit?: boolean;
}

export interface GameState {
  world: World;
  year: number;
  civs: Civ[];
  cities: City[];
  wars: War[];
  battles: Battle[];
  fx: FxItem[];
  rng: () => number;
  nextCivId: number;
  nextCityId: number;
  nextWarId: number;
  nextBattleId: number;
  nextFxId: number;
  usedNames: Set<string>;
}

export type EventKind =
  | "genesis"
  | "found"
  | "era"
  | "war"
  | "peace"
  | "ally"
  | "fall"
  | "disaster"
  | "bless"
  | "conquer";

export interface GameEvent {
  id: number;
  year: number;
  kind: EventKind;
  text: string;
  civ?: number;
}

/* ------------------------------------------------ Snapshots for React */
export interface CivSnap {
  id: number;
  name: string;
  color: string;
  era: number;
  tech: number;
  pop: number;
  military: number;
  blessed: number;
  territorySize: number;
  citiesCount: number;
  capital: number; // city id or -1
  founded: number;
  wars: number;
  allies: { id: number; name: string; color: string }[];
  enemies: { id: number; name: string; color: string }[];
}

export interface WorldStats {
  pop: number;
  civs: number;
  cities: number;
  wars: number;
  eraDist: number[]; // civs per era
}

export const CIV_COLORS = [
  "#e4534b",
  "#f2a541",
  "#8f6fde",
  "#2fb7c9",
  "#e562a7",
  "#7ac74f",
  "#ef7d3a",
  "#3fa4f5",
  "#c6d64e",
  "#d96b43",
];
