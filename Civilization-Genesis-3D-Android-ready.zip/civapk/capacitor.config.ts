import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.civilizationgenesis.game',
  appName: 'Civilization Genesis 3D',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#10131b',
  },
};

export default config;
